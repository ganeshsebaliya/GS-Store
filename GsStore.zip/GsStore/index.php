<?php
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gs Store | Build With Satya</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .scroll-hide::-webkit-scrollbar { display: none; }
        .scroll-hide { -ms-overflow-style: none; scrollbar-width: none; }
        .scroll-btn:hover { transform: scale(1.1); }
        .search-overlay { backdrop-filter: blur(5px); }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <!-- Logo -->
                <div class="flex items-center space-x-2">
                    <h1 class="text-white font-bold text-xl">Gs Store | Build With Satya</h1>
                </div>
                
                <!-- Search Icon -->
                <button id="searchToggle" class="text-white p-2 hover:bg-white/20 rounded-full transition">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                </button>
                
                <!-- Menu Icon -->
                <button id="menuToggle" class="text-white p-2 hover:bg-white/20 rounded-full transition">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>
            </div>
            
            <!-- Search Bar -->
            <div id="searchBar" class="hidden mt-3">
                <div class="relative">
                    <input type="text" id="searchInput" 
                           class="w-full px-4 py-3 pl-12 rounded-xl bg-white/90 focus:outline-none focus:ring-2 focus:ring-blue-500"
                           placeholder="Search apps...">
                    <div class="absolute left-4 top-3.5">
                        <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                    </div>
                </div>
                <div id="searchResults" class="mt-2 bg-white rounded-xl shadow-lg max-h-80 overflow-y-auto hidden"></div>
            </div>
        </div>
    </header>
    
    <!-- Mobile Menu -->
    <div id="mobileMenu" class="fixed inset-0 z-50 bg-black/50 hidden">
        <div class="absolute right-0 top-0 h-full w-64 bg-white shadow-xl">
            <div class="p-4 border-b">
                <button id="closeMenu" class="float-right text-gray-600 hover:text-gray-900">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
                <h3 class="text-lg font-semibold text-gray-800">Menu</h3>
            </div>
            <nav class="p-4">
                <a href="index.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-blue-50 text-gray-700 hover:text-blue-600 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                    </svg>
                    <span>Home</span>
                </a>
                <a href="category.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-blue-50 text-gray-700 hover:text-blue-600 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                    </svg>
                    <span>Categories</span>
                </a>
                <a href="profile.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-blue-50 text-gray-700 hover:text-blue-600 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                    </svg>
                    <span>Profile</span>
                </a>
                <?php if(isset($_SESSION['user_id'])): ?>
                <a href="logout.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-red-50 text-red-600 hover:text-red-700 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                    </svg>
                    <span>Logout</span>
                </a>
                <?php else: ?>
                <a href="login.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-green-50 text-green-600 hover:text-green-700 transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"></path>
                    </svg>
                    <span>Login</span>
                </a>
                <?php endif; ?>
            </nav>
        </div>
    </div>
    
    <!-- Main Content -->
    <main class="container mx-auto px-4 py-6 pb-24">
        <?php
        // Fetch featured app and banner
        $featured_sql = "SELECT s.banner_image, s.featured_app_id, a.title 
                        FROM settings s 
                        LEFT JOIN apps a ON s.featured_app_id = a.id 
                        WHERE s.id = 1";
        $featured_result = $conn->query($featured_sql);
        $featured = $featured_result->fetch_assoc();
        
        // Show banner only if both banner_image and featured_app_id exist
        if($featured && !empty($featured['banner_image']) && !empty($featured['featured_app_id'])): 
        ?>
        <!-- App of the Week Banner -->
        <section class="mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-4">App of the Week</h2>
            <a href="app.php?id=<?php echo $featured['featured_app_id']; ?>">
                <div class="relative rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                    <img src="assets/uploads/banners/<?php echo htmlspecialchars($featured['banner_image']); ?>" 
                         alt="<?php echo htmlspecialchars($featured['title']); ?>"
                         class="w-full h-48 md:h-64 object-cover">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div class="absolute bottom-4 left-6 text-white">
                        <h3 class="text-xl font-bold"><?php echo htmlspecialchars($featured['title']); ?></h3>
                        <p class="text-sm opacity-90">Featured App</p>
                    </div>
                </div>
            </a>
        </section>
        <?php endif; ?>
        
        <!-- Trending Apps -->
        <section class="mb-10">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-2xl font-bold text-gray-800">Trending Apps</h2>
                <div class="flex space-x-2">
                    <button onclick="scrollLeft('trending')" class="scroll-btn p-2 rounded-full bg-white shadow hover:shadow-md transition">
                        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                        </svg>
                    </button>
                    <button onclick="scrollRight('trending')" class="scroll-btn p-2 rounded-full bg-white shadow hover:shadow-md transition">
                        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                        </svg>
                    </button>
                </div>
            </div>
            
            <div id="trending" class="flex overflow-x-auto scroll-hide space-x-4 pb-4">
                <?php
                $trending_sql = "SELECT a.id, a.title, a.icon, a.downloads 
                                FROM apps a 
                                WHERE a.status = 'approved' 
                                ORDER BY a.downloads DESC 
                                LIMIT 20";
                $trending_stmt = $conn->prepare($trending_sql);
                $trending_stmt->execute();
                $trending_result = $trending_stmt->get_result();
                
                while($app = $trending_result->fetch_assoc()):
                ?>
                <a href="app.php?id=<?php echo $app['id']; ?>" 
                   class="flex-shrink-0 w-32 bg-white rounded-xl shadow-md hover:shadow-lg hover:scale-105 transition-transform duration-200">
                    <div class="p-4">
                        <img src="assets/uploads/icons/<?php echo htmlspecialchars($app['icon']); ?>" 
                             alt="<?php echo htmlspecialchars($app['title']); ?>"
                             class="w-16 h-16 mx-auto rounded-xl object-cover">
                        <h3 class="mt-3 text-sm font-semibold text-gray-800 text-center truncate"><?php echo htmlspecialchars($app['title']); ?></h3>
                        <p class="text-xs text-gray-500 text-center mt-1"><?php echo number_format($app['downloads']); ?> downloads</p>
                    </div>
                </a>
                <?php endwhile; 
                $trending_stmt->close();
                ?>
            </div>
        </section>
        
        <!-- Newest Apps -->
        <section class="mb-10">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-2xl font-bold text-gray-800">Newest Apps</h2>
                <div class="flex space-x-2">
                    <button onclick="scrollLeft('newest')" class="scroll-btn p-2 rounded-full bg-white shadow hover:shadow-md transition">
                        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                        </svg>
                    </button>
                    <button onclick="scrollRight('newest')" class="scroll-btn p-2 rounded-full bg-white shadow hover:shadow-md transition">
                        <svg class="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                        </svg>
                    </button>
                </div>
            </div>
            
            <div id="newest" class="flex overflow-x-auto scroll-hide space-x-4 pb-4">
                <?php
                $newest_sql = "SELECT a.id, a.title, a.icon, DATE_FORMAT(a.created_at, '%b %d') as created 
                              FROM apps a 
                              WHERE a.status = 'approved' 
                              ORDER BY a.created_at DESC 
                              LIMIT 20";
                $newest_stmt = $conn->prepare($newest_sql);
                $newest_stmt->execute();
                $newest_result = $newest_stmt->get_result();
                
                while($app = $newest_result->fetch_assoc()):
                ?>
                <a href="app.php?id=<?php echo $app['id']; ?>" 
                   class="flex-shrink-0 w-32 bg-white rounded-xl shadow-md hover:shadow-lg hover:scale-105 transition-transform duration-200">
                    <div class="p-4">
                        <img src="assets/uploads/icons/<?php echo htmlspecialchars($app['icon']); ?>" 
                             alt="<?php echo htmlspecialchars($app['title']); ?>"
                             class="w-16 h-16 mx-auto rounded-xl object-cover">
                        <h3 class="mt-3 text-sm font-semibold text-gray-800 text-center truncate"><?php echo htmlspecialchars($app['title']); ?></h3>
                        <p class="text-xs text-gray-500 text-center mt-1">Added <?php echo $app['created']; ?></p>
                    </div>
                </a>
                <?php endwhile; 
                $newest_stmt->close();
                ?>
            </div>
        </section>
        
        <!-- Categories Grid -->
        <section class="mb-10">
            <h2 class="text-2xl font-bold text-gray-800 mb-4">Browse Categories</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <?php
                $cats_sql = "SELECT c.id, c.name, COUNT(a.id) as app_count 
                            FROM categories c 
                            LEFT JOIN apps a ON c.id = a.category_id AND a.status = 'approved' 
                            GROUP BY c.id 
                            ORDER BY c.name";
                $cats_stmt = $conn->prepare($cats_sql);
                $cats_stmt->execute();
                $cats_result = $cats_stmt->get_result();
                
                while($cat = $cats_result->fetch_assoc()):
                ?>
                <a href="category.php?cat_id=<?php echo $cat['id']; ?>" 
                   class="bg-white rounded-xl shadow-md hover:shadow-lg p-6 text-center hover:scale-105 transition-transform">
                    <div class="text-3xl mb-2">📱</div>
                    <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($cat['name']); ?></h3>
                    <p class="text-sm text-gray-500 mt-1"><?php echo $cat['app_count']; ?> apps</p>
                </a>
                <?php endwhile; 
                $cats_stmt->close();
                ?>
            </div>
        </section>
    </main>
    
    <!-- Footer Navigation -->
    <footer class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-3 z-40">
        <div class="container mx-auto px-4">
            <div class="flex justify-around">
                <a href="index.php" class="flex flex-col items-center text-blue-600">
                    <div class="p-2 rounded-full bg-blue-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </div>
                    <span class="text-xs mt-1">Home</span>
                </a>
                
                <a href="category.php" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
                    <div class="p-2 rounded-full hover:bg-blue-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                        </svg>
                    </div>
                    <span class="text-xs mt-1">Categories</span>
                </a>
                
                <a href="profile.php" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
                    <div class="p-2 rounded-full hover:bg-blue-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                    </div>
                    <span class="text-xs mt-1">Profile</span>
                </a>
            </div>
        </div>
    </footer>
    
    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const mobileMenu = document.getElementById('mobileMenu');
        const closeMenu = document.getElementById('closeMenu');
        
        menuToggle.addEventListener('click', () => mobileMenu.classList.remove('hidden'));
        closeMenu.addEventListener('click', () => mobileMenu.classList.add('hidden'));
        mobileMenu.addEventListener('click', (e) => {
            if(e.target === mobileMenu) mobileMenu.classList.add('hidden');
        });
        
        // Search toggle
        const searchToggle = document.getElementById('searchToggle');
        const searchBar = document.getElementById('searchBar');
        const searchInput = document.getElementById('searchInput');
        const searchResults = document.getElementById('searchResults');
        
        searchToggle.addEventListener('click', () => {
            searchBar.classList.toggle('hidden');
            if(!searchBar.classList.contains('hidden')) {
                searchInput.focus();
            }
        });
        
        // Live search
        let searchTimeout;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            const query = this.value.trim();
            
            if(query.length < 2) {
                searchResults.classList.add('hidden');
                return;
            }
            
            searchTimeout = setTimeout(() => {
                fetch(`search.php?q=${encodeURIComponent(query)}`)
                    .then(response => response.text())
                    .then(html => {
                        searchResults.innerHTML = html;
                        searchResults.classList.remove('hidden');
                    });
            }, 300);
        });
        
        // Close search when clicking outside
        document.addEventListener('click', (e) => {
            if(!searchBar.contains(e.target) && !searchToggle.contains(e.target)) {
                searchResults.classList.add('hidden');
            }
        });
        
        // Horizontal scroll functions
        function scrollLeft(containerId) {
            const container = document.getElementById(containerId);
            container.scrollBy({ left: -300, behavior: 'smooth' });
        }
        
        function scrollRight(containerId) {
            const container = document.getElementById(containerId);
            container.scrollBy({ left: 300, behavior: 'smooth' });
        }
        
        // Footer button animation
        document.querySelectorAll('footer a').forEach(link => {
            link.addEventListener('click', function(e) {
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 200);
            });
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>