<?php
require_once 'config.php';

$tables = [];

// Users table
$tables[] = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user','publisher','admin') DEFAULT 'user',
    status ENUM('active','banned') DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)";

// Categories table
$tables[] = "CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL
)";

// Apps table
$tables[] = "CREATE TABLE IF NOT EXISTS apps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    icon VARCHAR(255) NOT NULL,
    screenshots TEXT,
    category_id INT,
    version VARCHAR(50) NOT NULL,
    size VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    publisher_id INT NOT NULL,
    drive_link TEXT NOT NULL,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    downloads INT DEFAULT 0,
    is_featured TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    FOREIGN KEY (publisher_id) REFERENCES users(id) ON DELETE CASCADE
)";

// Reviews table
$tables[] = "CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    app_id INT NOT NULL,
    rating TINYINT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (app_id) REFERENCES apps(id) ON DELETE CASCADE
)";

// Settings table
$tables[] = "CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    site_name VARCHAR(255) DEFAULT 'Gs Store',
    logo VARCHAR(255),
    banner_image VARCHAR(255),
    featured_app_id INT,
    FOREIGN KEY (featured_app_id) REFERENCES apps(id) ON DELETE SET NULL
)";

// Downloads table
$tables[] = "CREATE TABLE IF NOT EXISTS downloads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    app_id INT NOT NULL,
    ip_address VARCHAR(45),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (app_id) REFERENCES apps(id) ON DELETE CASCADE
)";

// Publisher requests table
$tables[] = "CREATE TABLE IF NOT EXISTS publisher_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
)";

// Indexes
$indexes = [
    "CREATE INDEX idx_apps_status ON apps(status)",
    "CREATE INDEX idx_apps_featured ON apps(is_featured)",
    "CREATE INDEX idx_apps_downloads ON apps(downloads)",
    "CREATE INDEX idx_apps_created ON apps(created_at)",
    "CREATE INDEX idx_reviews_app ON reviews(app_id)",
    "CREATE INDEX idx_downloads_app ON downloads(app_id)"
];

echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen p-4">
    <div class="max-w-4xl mx-auto">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Gs Store Installation</h1>
        <div class="bg-white rounded-xl shadow-md p-6">';

$success = true;
foreach ($tables as $tableSQL) {
    if ($conn->query($tableSQL) === TRUE) {
        echo '<p class="text-green-600 mb-2">✓ Table created successfully</p>';
    } else {
        echo '<p class="text-red-600 mb-2">✗ Error creating table: ' . $conn->error . '</p>';
        $success = false;
    }
}

foreach ($indexes as $indexSQL) {
    if ($conn->query($indexSQL) === TRUE) {
        echo '<p class="text-green-600 mb-2">✓ Index created successfully</p>';
    } else {
        echo '<p class="text-yellow-600 mb-2">⚠ Index creation: ' . $conn->error . '</p>';
    }
}

// Insert default settings
$defaultSettings = "INSERT IGNORE INTO settings (id, site_name) VALUES (1, 'Gs Store')";
if ($conn->query($defaultSettings) === TRUE) {
    echo '<p class="text-green-600 mb-2">✓ Default settings inserted</p>';
}

if ($success) {
    echo '<div class="mt-8 p-4 bg-green-50 border border-green-200 rounded-lg">
            <h2 class="text-xl font-bold text-green-800 mb-2">Installation Complete!</h2>
            <p class="text-green-700 mb-4">All database tables have been created successfully.</p>
            <div class="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <h3 class="font-bold text-yellow-800 mb-2">⚠ Important Security Notice</h3>
                <p class="text-yellow-700">For security reasons, you should:</p>
                <ol class="list-decimal ml-5 text-yellow-700 mt-2">
                    <li>Delete or rename this install.php file immediately</li>
                    <li>Create your first admin account by visiting register.php</li>
                    <li>Update the admin user role manually in database if needed</li>
                </ol>
            </div>
            <div class="mt-6">
                <a href="index.php" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition">Go to Homepage</a>
                <a href="register.php" class="inline-block bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition ml-4">Register First User</a>
            </div>
        </div>';
} else {
    echo '<div class="mt-8 p-4 bg-red-50 border border-red-200 rounded-lg">
            <h2 class="text-xl font-bold text-red-800 mb-2">Installation Failed</h2>
            <p class="text-red-700">There were errors during installation. Please check your database configuration.</p>
        </div>';
}

echo '</div></div></body></html>';
?>