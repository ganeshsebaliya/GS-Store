<?php
$host = "sql200.infinityfree.com";
$user = "if0_40774491";
$pass = "040600Gs";
$dbname = "if0_40774491_GsStore";
$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
  die("Database Connection Failed: " . $conn->connect_error);
}
session_start();
?>