<?php
require_once '../config.php';

// Check if user is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Handle actions
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $app_id = intval($_POST['app_id']);
    $action = $_POST['action'];
    
    if($action === 'approve') {
        $update = $conn->prepare("UPDATE apps SET status = 'approved' WHERE id = ?");
        $update->bind_param("i", $app_id);
        $update->execute();
        $update->close();
    } elseif($action === 'reject') {
        $update = $conn->prepare("UPDATE apps SET status = 'rejected' WHERE id = ?");
        $update->bind_param("i", $app_id);
        $update->execute();
        $update->close();
    } elseif($action === 'delete') {
        // Get app details for file deletion
        $get_app = $conn->prepare("SELECT icon, screenshots FROM apps WHERE id = ?");
        $get_app->bind_param("i", $app_id);
        $get_app->execute();
        $app_result = $get_app->get_result();
        
        if($app_result->num_rows === 1) {
            $app = $app_result->fetch_assoc();
            
            // Delete icon
            if($app['icon']) {
                $icon_path = "../assets/uploads/icons/" . $app['icon'];
                if(file_exists($icon_path)) {
                    unlink($icon_path);
                }
            }
            
            // Delete screenshots
            $screenshots = json_decode($app['screenshots'], true);
            if(is_array($screenshots)) {
                foreach($screenshots as $screenshot) {
                    $screenshot_path = "../assets/uploads/screenshots/" . $screenshot;
                    if(file_exists($screenshot_path)) {
                        unlink($screenshot_path);
                    }
                }
            }
        }
        $get_app->close();
        
        // Delete from database
        $delete = $conn->prepare("DELETE FROM apps WHERE id = ?");
        $delete->bind_param("i", $app_id);
        $delete->execute();
        $delete->close();
    } elseif($action === 'feature') {
        // Unfeature all apps first
        $unfeature = $conn->prepare("UPDATE apps SET is_featured = 0 WHERE is_featured = 1");
        $unfeature->execute();
        $unfeature->close();
        
        // Feature this app
        $feature = $conn->prepare("UPDATE apps SET is_featured = 1 WHERE id = ?");
        $feature->bind_param("i", $app_id);
        $feature->execute();
        $feature->close();
    }
    
    header("Location: apps.php");
    exit();
}

// Filter by status
$status = isset($_GET['status']) ? $_GET['status'] : 'all';
$status_filter = '';

switch($status) {
    case 'pending':
        $status_filter = "WHERE a.status = 'pending'";
        break;
    case 'approved':
        $status_filter = "WHERE a.status = 'approved'";
        break;
    case 'rejected':
        $status_filter = "WHERE a.status = 'rejected'";
        break;
    case 'featured':
        $status_filter = "WHERE a.is_featured = 1";
        break;
}

// Fetch apps with filters
$apps_sql = "SELECT a.*, u.name as publisher_name, c.name as category_name 
            FROM apps a 
            LEFT JOIN users u ON a.publisher_id = u.id 
            LEFT JOIN categories c ON a.category_id = c.id 
            $status_filter 
            ORDER BY a.created_at DESC";
$apps_result = $conn->query($apps_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Apps - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-red-600 to-pink-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <a href="../index.php" class="text-white font-bold text-xl">Gs Store</a>
                    <span class="text-white/80">|</span>
                    <span class="text-white font-medium">Manage Apps</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </a>
                    <a href="../logout.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-7xl mx-auto">
            <!-- Breadcrumb -->
            <div class="mb-6">
                <nav class="flex space-x-2 text-sm text-gray-600">
                    <a href="../index.php" class="hover:text-red-600">Home</a>
                    <span>/</span>
                    <a href="dashboard.php" class="hover:text-red-600">Admin</a>
                    <span>/</span>
                    <span class="text-gray-800 font-medium">Manage Apps</span>
                </nav>
            </div>
            
            <!-- Header -->
            <div class="flex flex-col md:flex-row md:items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Manage Apps</h1>
                    <p class="text-gray-600">Review and manage all applications</p>
                </div>
                <div class="mt-4 md:mt-0">
                    <span class="text-sm text-gray-500">Total: <?php echo $apps_result->num_rows; ?> apps</span>
                </div>
            </div>
            
            <!-- Filters -->
            <div class="bg-white rounded-xl shadow-lg p-4 mb-6">
                <div class="flex flex-wrap gap-2">
                    <a href="?status=all" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $status === 'all' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        All Apps
                    </a>
                    <a href="?status=pending" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Pending
                    </a>
                    <a href="?status=approved" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $status === 'approved' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Approved
                    </a>
                    <a href="?status=rejected" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Rejected
                    </a>
                    <a href="?status=featured" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $status === 'featured' ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Featured
                    </a>
                </div>
            </div>
            
            <!-- Apps Table -->
            <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                <?php if($apps_result->num_rows > 0): ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">App</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Publisher</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Downloads</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php while($app = $apps_result->fetch_assoc()): 
                                $status_color = $app['status'] === 'approved' ? 'bg-green-100 text-green-800' : 
                                              ($app['status'] === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                              'bg-red-100 text-red-800');
                                $featured_badge = $app['is_featured'] ? '<span class="ml-1 px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full">Featured</span>' : '';
                            ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4">
                                    <div class="flex items-center space-x-3">
                                        <img src="../assets/uploads/icons/<?php echo htmlspecialchars($app['icon']); ?>" 
                                             alt="<?php echo htmlspecialchars($app['title']); ?>"
                                             class="w-10 h-10 rounded-lg object-cover">
                                        <div>
                                            <div class="flex items-center">
                                                <h4 class="font-medium text-gray-800"><?php echo htmlspecialchars($app['title']); ?></h4>
                                                <?php echo $featured_badge; ?>
                                            </div>
                                            <p class="text-sm text-gray-500"><?php echo htmlspecialchars($app['category_name']); ?></p>
                                            <a href="../app.php?id=<?php echo $app['id']; ?>" 
                                               class="text-xs text-blue-600 hover:text-blue-700">View Details</a>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-700"><?php echo htmlspecialchars($app['publisher_name']); ?></td>
                                <td class="px-6 py-4">
                                    <span class="px-3 py-1 rounded-full text-xs font-medium <?php echo $status_color; ?>">
                                        <?php echo ucfirst($app['status']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-700"><?php echo number_format($app['downloads']); ?></td>
                                <td class="px-6 py-4 text-sm text-gray-700"><?php echo date('M d, Y', strtotime($app['created_at'])); ?></td>
                                <td class="px-6 py-4">
                                    <div class="flex items-center space-x-2">
                                        <?php if($app['status'] === 'pending'): ?>
                                        <form method="POST" class="inline" onsubmit="return confirm('Approve this app?');">
                                            <input type="hidden" name="app_id" value="<?php echo $app['id']; ?>">
                                            <input type="hidden" name="action" value="approve">
                                            <button type="submit" 
                                                    class="text-green-600 hover:text-green-700 p-1 hover:bg-green-50 rounded">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                                </svg>
                                            </button>
                                        </form>
                                        <form method="POST" class="inline" onsubmit="return confirm('Reject this app?');">
                                            <input type="hidden" name="app_id" value="<?php echo $app['id']; ?>">
                                            <input type="hidden" name="action" value="reject">
                                            <button type="submit" 
                                                    class="text-red-600 hover:text-red-700 p-1 hover:bg-red-50 rounded">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                                                </svg>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                        
                                        <?php if($app['status'] === 'approved' && !$app['is_featured']): ?>
                                        <form method="POST" class="inline" onsubmit="return confirm('Feature this app as App of the Week?');">
                                            <input type="hidden" name="app_id" value="<?php echo $app['id']; ?>">
                                            <input type="hidden" name="action" value="feature">
                                            <button type="submit" 
                                                    class="text-purple-600 hover:text-purple-700 p-1 hover:bg-purple-50 rounded">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path>
                                                </svg>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                        
                                        <form method="POST" class="inline" onsubmit="return confirm('Are you sure you want to delete this app? This action cannot be undone.');">
                                            <input type="hidden" name="app_id" value="<?php echo $app['id']; ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <button type="submit" 
                                                    class="text-gray-600 hover:text-gray-700 p-1 hover:bg-gray-50 rounded">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                </svg>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-12">
                    <div class="text-gray-400 mb-4">
                        <svg class="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-600 mb-2">No apps found</h3>
                    <p class="text-gray-500">Try selecting a different filter</p>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-6">
                <a href="dashboard.php" class="inline-flex items-center text-red-600 hover:text-red-700">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                    </svg>
                    Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>