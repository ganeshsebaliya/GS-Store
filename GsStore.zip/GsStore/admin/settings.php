<?php
require_once '../config.php';

// Check if user is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$message = '';
$error = '';

// Fetch current settings
$settings_sql = "SELECT * FROM settings WHERE id = 1";
$settings_result = $conn->query($settings_sql);
$settings = $settings_result->fetch_assoc();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_name = trim($_POST['site_name']);
    $logo = $settings['logo']; // Keep existing unless new uploaded
    
    // Handle logo upload
    if(isset($_FILES['logo']) && $_FILES['logo']['error'] === 0) {
        $file = $_FILES['logo'];
        
        // Validate file
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif', 'image/svg+xml'];
        $max_size = 2 * 1024 * 1024; // 2MB
        
        if(in_array($file['type'], $allowed_types) && $file['size'] <= $max_size) {
            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'logo_' . time() . '.' . $extension;
            $target_file = '../assets/uploads/' . $filename;
            
            // Delete old logo if exists
            if(!empty($settings['logo'])) {
                $old_file = '../assets/uploads/' . $settings['logo'];
                if(file_exists($old_file)) {
                    unlink($old_file);
                }
            }
            
            // Move uploaded file
            if(move_uploaded_file($file['tmp_name'], $target_file)) {
                $logo = $filename;
            } else {
                $error = "Failed to upload logo";
            }
        } else {
            $error = "Invalid logo file. Please upload JPEG, PNG, GIF or SVG image (max 2MB)";
        }
    }
    
    if(empty($error)) {
        $update = $conn->prepare("UPDATE settings SET site_name = ?, logo = ? WHERE id = 1");
        $update->bind_param("ss", $site_name, $logo);
        
        if($update->execute()) {
            $message = "Settings updated successfully!";
            // Refresh settings
            $settings['site_name'] = $site_name;
            $settings['logo'] = $logo;
        } else {
            $error = "Failed to update settings";
        }
        $update->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site Settings - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-red-600 to-pink-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <a href="../index.php" class="text-white font-bold text-xl">Gs Store</a>
                    <span class="text-white/80">|</span>
                    <span class="text-white font-medium">Site Settings</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </a>
                    <a href="../logout.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            <!-- Breadcrumb -->
            <div class="mb-6">
                <nav class="flex space-x-2 text-sm text-gray-600">
                    <a href="../index.php" class="hover:text-red-600">Home</a>
                    <span>/</span>
                    <a href="dashboard.php" class="hover:text-red-600">Admin</a>
                    <span>/</span>
                    <span class="text-gray-800 font-medium">Settings</span>
                </nav>
            </div>
            
            <!-- Messages -->
            <?php if($error): ?>
            <div class="mb-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>
            
            <?php if($message): ?>
            <div class="mb-6 p-4 bg-green-50 border border-green-200 text-green-700 rounded-xl">
                <?php echo htmlspecialchars($message); ?>
            </div>
            <?php endif; ?>
            
            <!-- Settings Form -->
            <div class="bg-white rounded-2xl shadow-xl p-6">
                <h1 class="text-2xl font-bold text-gray-800 mb-6">Site Settings</h1>
                
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="space-y-8">
                        <!-- Site Name -->
                        <div>
                            <label class="block text-gray-700 text-sm font-medium mb-2">Site Name *</label>
                            <input type="text" name="site_name" required value="<?php echo htmlspecialchars($settings['site_name']); ?>"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                                   placeholder="Your Store Name">
                            <p class="text-sm text-gray-500 mt-2">This name appears in the header and browser tab</p>
                        </div>
                        
                        <!-- Logo -->
                        <div>
                            <label class="block text-gray-700 text-sm font-medium mb-2">Site Logo</label>
                            
                            <?php if($settings['logo']): ?>
                            <div class="mb-4 p-4 border border-gray-200 rounded-xl">
                                <p class="text-sm text-gray-600 mb-2">Current Logo:</p>
                                <img src="../assets/uploads/<?php echo htmlspecialchars($settings['logo']); ?>" 
                                     alt="Current Logo"
                                     class="w-32 h-32 object-contain">
                                <p class="text-xs text-gray-500 mt-2"><?php echo htmlspecialchars($settings['logo']); ?></p>
                            </div>
                            <?php endif; ?>
                            
                            <div class="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-red-400 transition">
                                <input type="file" name="logo" accept="image/png, image/jpeg, image/jpg, image/gif, image/svg+xml" 
                                       class="hidden" id="logoInput" onchange="previewLogo(event)">
                                <label for="logoInput" class="cursor-pointer">
                                    <div class="mx-auto w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center mb-3">
                                        <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                        </svg>
                                    </div>
                                    <p class="text-sm text-gray-600">Click to upload new logo</p>
                                    <p class="text-xs text-gray-500 mt-1">PNG, JPG, GIF or SVG, max 2MB</p>
                                    <p class="text-xs text-gray-500 mt-1">Recommended size: 200×200 pixels</p>
                                </label>
                            </div>
                            <div id="logoPreview" class="mt-4 hidden">
                                <p class="text-sm text-gray-600 mb-2">New logo preview:</p>
                                <img id="logoPreviewImg" class="w-32 h-32 object-contain border rounded-lg">
                            </div>
                            <p class="text-sm text-gray-500 mt-2">Leave empty to keep current logo</p>
                        </div>
                        
                        <!-- SEO Settings -->
                        <div class="pt-6 border-t">
                            <h3 class="text-lg font-semibold text-gray-800 mb-4">SEO Settings (Optional)</h3>
                            
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-gray-700 text-sm font-medium mb-2">Meta Description</label>
                                    <textarea name="meta_description" rows="3"
                                              class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                                              placeholder="Brief description of your store for search engines"></textarea>
                                </div>
                                
                                <div>
                                    <label class="block text-gray-700 text-sm font-medium mb-2">Keywords</label>
                                    <input type="text" name="keywords"
                                           class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                                           placeholder="comma, separated, keywords">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Submit -->
                        <div class="pt-6 border-t">
                            <div class="flex justify-between items-center">
                                <a href="dashboard.php" class="text-gray-600 hover:text-gray-800 font-medium">
                                    ← Back to Dashboard
                                </a>
                                <button type="submit" 
                                        class="bg-gradient-to-r from-red-500 to-pink-600 text-white font-bold py-3 px-8 rounded-xl hover:shadow-lg transition-transform active:scale-95">
                                    Save Settings
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Current Configuration -->
            <div class="mt-6 bg-white rounded-2xl shadow-lg p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">Current Configuration</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-gray-50 p-4 rounded-xl">
                        <p class="text-sm text-gray-500">Database</p>
                        <p class="font-medium">Connected to InfinityFree</p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-xl">
                        <p class="text-sm text-gray-500">Upload Directory</p>
                        <p class="font-medium">assets/uploads/</p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-xl">
                        <p class="text-sm text-gray-500">PHP Version</p>
                        <p class="font-medium"><?php echo phpversion(); ?></p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-xl">
                        <p class="text-sm text-gray-500">MySQL Version</p>
                        <p class="font-medium"><?php echo $conn->server_info; ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="mt-6 bg-yellow-50 border border-yellow-200 rounded-xl p-6">
                <h3 class="text-lg font-semibold text-yellow-800 mb-4">⚠ System Actions</h3>
                <div class="space-y-3">
                    <a href="dashboard.php" 
                       class="block text-center py-2 px-4 bg-yellow-100 text-yellow-800 rounded-lg hover:bg-yellow-200 transition">
                        View System Statistics
                    </a>
                    <a href="../install.php" 
                       class="block text-center py-2 px-4 bg-red-100 text-red-800 rounded-lg hover:bg-red-200 transition">
                        Database Installer (Danger Zone)
                    </a>
                    <p class="text-sm text-yellow-700 mt-4">
                        <strong>Note:</strong> The installer should be deleted after initial setup for security.
                    </p>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Preview logo
        function previewLogo(event) {
            const input = event.target;
            const preview = document.getElementById('logoPreview');
            const img = document.getElementById('logoPreviewImg');
            
            if(input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    img.src = e.target.result;
                    preview.classList.remove('hidden');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        // Form submission
        const form = document.querySelector('form');
        form.addEventListener('submit', function() {
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = 'Saving...';
            submitBtn.classList.add('opacity-75');
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>