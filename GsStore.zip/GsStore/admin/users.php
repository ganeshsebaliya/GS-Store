<?php
require_once '../config.php';

// Check if user is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$message = '';
$error = '';

// Handle user actions
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = intval($_POST['user_id']);
    $action = $_POST['action'];
    
    if($action === 'ban') {
        $update = $conn->prepare("UPDATE users SET status = 'banned' WHERE id = ?");
        $update->bind_param("i", $user_id);
        $update->execute();
        $update->close();
        $message = "User banned successfully";
    } elseif($action === 'unban') {
        $update = $conn->prepare("UPDATE users SET status = 'active' WHERE id = ?");
        $update->bind_param("i", $user_id);
        $update->execute();
        $update->close();
        $message = "User unbanned successfully";
    } elseif($action === 'delete') {
        // Check if user has apps
        $check_apps = $conn->prepare("SELECT COUNT(*) as app_count FROM apps WHERE publisher_id = ?");
        $check_apps->bind_param("i", $user_id);
        $check_apps->execute();
        $result = $check_apps->get_result();
        $data = $result->fetch_assoc();
        
        if($data['app_count'] > 0) {
            $error = "Cannot delete user with published apps. Delete their apps first.";
        } else {
            $delete = $conn->prepare("DELETE FROM users WHERE id = ?");
            $delete->bind_param("i", $user_id);
            $delete->execute();
            $delete->close();
            $message = "User deleted successfully";
        }
        $check_apps->close();
    } elseif($action === 'make_publisher') {
        $update = $conn->prepare("UPDATE users SET role = 'publisher' WHERE id = ?");
        $update->bind_param("i", $user_id);
        $update->execute();
        $update->close();
        
        // Approve any pending requests
        $approve_request = $conn->prepare("UPDATE publisher_requests SET status = 'approved' WHERE user_id = ?");
        $approve_request->bind_param("i", $user_id);
        $approve_request->execute();
        $approve_request->close();
        
        $message = "User promoted to publisher";
    } elseif($action === 'make_admin') {
        $update = $conn->prepare("UPDATE users SET role = 'admin' WHERE id = ?");
        $update->bind_param("i", $user_id);
        $update->execute();
        $update->close();
        $message = "User promoted to admin";
    } elseif($action === 'make_user') {
        $update = $conn->prepare("UPDATE users SET role = 'user' WHERE id = ?");
        $update->bind_param("i", $user_id);
        $update->execute();
        $update->close();
        $message = "User demoted to regular user";
    }
}

// Filter users
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$role_filter = '';
$status_filter = '';

switch($filter) {
    case 'users':
        $role_filter = "WHERE role = 'user'";
        break;
    case 'publishers':
        $role_filter = "WHERE role = 'publisher'";
        break;
    case 'admins':
        $role_filter = "WHERE role = 'admin'";
        break;
    case 'banned':
        $status_filter = "WHERE status = 'banned'";
        break;
    case 'active':
        $status_filter = "WHERE status = 'active'";
        break;
    case 'pending_requests':
        // This is for publisher requests
        break;
}

// Fetch users
if($filter === 'pending_requests') {
    $users_sql = "SELECT pr.*, u.name, u.email, u.role, u.status, u.created_at 
                 FROM publisher_requests pr 
                 JOIN users u ON pr.user_id = u.id 
                 WHERE pr.status = 'pending' 
                 ORDER BY pr.created_at DESC";
} else {
    $users_sql = "SELECT u.*, 
                 (SELECT COUNT(*) FROM apps WHERE publisher_id = u.id) as app_count,
                 (SELECT COUNT(*) FROM downloads WHERE user_id = u.id) as download_count
                 FROM users u 
                 {$role_filter} {$status_filter}
                 ORDER BY u.created_at DESC";
}
$users_result = $conn->query($users_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-red-600 to-pink-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <a href="../index.php" class="text-white font-bold text-xl">Gs Store</a>
                    <span class="text-white/80">|</span>
                    <span class="text-white font-medium">Manage Users</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </a>
                    <a href="../logout.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-7xl mx-auto">
            <!-- Breadcrumb -->
            <div class="mb-6">
                <nav class="flex space-x-2 text-sm text-gray-600">
                    <a href="../index.php" class="hover:text-red-600">Home</a>
                    <span>/</span>
                    <a href="dashboard.php" class="hover:text-red-600">Admin</a>
                    <span>/</span>
                    <span class="text-gray-800 font-medium">Manage Users</span>
                </nav>
            </div>
            
            <!-- Messages -->
            <?php if($error): ?>
            <div class="mb-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>
            
            <?php if($message): ?>
            <div class="mb-6 p-4 bg-green-50 border border-green-200 text-green-700 rounded-xl">
                <?php echo htmlspecialchars($message); ?>
            </div>
            <?php endif; ?>
            
            <!-- Header -->
            <div class="flex flex-col md:flex-row md:items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">Manage Users</h1>
                    <p class="text-gray-600">View and manage all user accounts</p>
                </div>
                <div class="mt-4 md:mt-0">
                    <span class="text-sm text-gray-500">Total: <?php echo $users_result->num_rows; ?> users</span>
                </div>
            </div>
            
            <!-- Filters -->
            <div class="bg-white rounded-xl shadow-lg p-4 mb-6">
                <div class="flex flex-wrap gap-2">
                    <a href="?filter=all" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $filter === 'all' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        All Users
                    </a>
                    <a href="?filter=users" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $filter === 'users' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Regular Users
                    </a>
                    <a href="?filter=publishers" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $filter === 'publishers' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Publishers
                    </a>
                    <a href="?filter=admins" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $filter === 'admins' ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Admins
                    </a>
                    <a href="?filter=active" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $filter === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Active
                    </a>
                    <a href="?filter=banned" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $filter === 'banned' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Banned
                    </a>
                    <a href="?filter=pending_requests" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $filter === 'pending_requests' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Pending Requests
                    </a>
                </div>
            </div>
            
            <!-- Users Table -->
            <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                <?php if($users_result->num_rows > 0): ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <?php if($filter !== 'pending_requests'): ?>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stats</th>
                                <?php else: ?>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Request Date</th>
                                <?php endif; ?>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Joined</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php while($user = $users_result->fetch_assoc()): 
                                $role_color = $user['role'] === 'admin' ? 'bg-purple-100 text-purple-800' : 
                                            ($user['role'] === 'publisher' ? 'bg-green-100 text-green-800' : 
                                            'bg-blue-100 text-blue-800');
                                $status_color = $user['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
                            ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4">
                                    <div class="flex items-center space-x-3">
                                        <div class="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                                            <span class="font-bold text-gray-600"><?php echo strtoupper(substr($user['name'], 0, 1)); ?></span>
                                        </div>
                                        <div>
                                            <h4 class="font-medium text-gray-800"><?php echo htmlspecialchars($user['name']); ?></h4>
                                            <p class="text-sm text-gray-500"><?php echo htmlspecialchars($user['email']); ?></p>
                                            <p class="text-xs text-gray-500">ID: <?php echo $user['id']; ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="px-3 py-1 rounded-full text-xs font-medium <?php echo $role_color; ?>">
                                        <?php echo ucfirst($user['role']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="px-3 py-1 rounded-full text-xs font-medium <?php echo $status_color; ?>">
                                        <?php echo ucfirst($user['status']); ?>
                                    </span>
                                </td>
                                
                                <?php if($filter !== 'pending_requests'): ?>
                                <td class="px-6 py-4">
                                    <div class="text-sm">
                                        <p class="text-gray-700"><?php echo $user['app_count'] ?? 0; ?> apps</p>
                                        <p class="text-gray-700"><?php echo $user['download_count'] ?? 0; ?> downloads</p>
                                    </div>
                                </td>
                                <?php else: ?>
                                <td class="px-6 py-4 text-sm text-gray-700">
                                    <?php echo date('M d, Y', strtotime($user['created_at'])); ?>
                                </td>
                                <?php endif; ?>
                                
                                <td class="px-6 py-4 text-sm text-gray-700">
                                    <?php echo date('M d, Y', strtotime($user['created_at'])); ?>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex items-center space-x-2">
                                        <?php if($filter === 'pending_requests'): ?>
                                        <form method="POST" onsubmit="return confirm('Approve this publisher request?');">
                                            <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                            <input type="hidden" name="action" value="make_publisher">
                                            <button type="submit" 
                                                    class="text-green-600 hover:text-green-700 p-1 hover:bg-green-50 rounded">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                                </svg>
                                            </button>
                                        </form>
                                        <form method="POST" onsubmit="return confirm('Reject this publisher request?');">
                                            <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                            <input type="hidden" name="action" value="reject_request">
                                            <button type="submit" 
                                                    class="text-red-600 hover:text-red-700 p-1 hover:bg-red-50 rounded">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                                                </svg>
                                            </button>
                                        </form>
                                        <?php else: ?>
                                        <!-- Role Management -->
                                        <?php if($user['role'] === 'user'): ?>
                                        <form method="POST" onsubmit="return confirm('Promote this user to publisher?');">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="action" value="make_publisher">
                                            <button type="submit" 
                                                    class="text-green-600 hover:text-green-700 p-1 hover:bg-green-50 rounded"
                                                    title="Make Publisher">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                                                </svg>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                        
                                        <?php if($user['role'] !== 'admin'): ?>
                                        <form method="POST" onsubmit="return confirm('Promote this user to admin?');">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="action" value="make_admin">
                                            <button type="submit" 
                                                    class="text-purple-600 hover:text-purple-700 p-1 hover:bg-purple-50 rounded"
                                                    title="Make Admin">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                                                </svg>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                        
                                        <?php if($user['role'] !== 'user' && $user['role'] !== 'admin'): ?>
                                        <form method="POST" onsubmit="return confirm('Demote to regular user?');">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="action" value="make_user">
                                            <button type="submit" 
                                                    class="text-blue-600 hover:text-blue-700 p-1 hover:bg-blue-50 rounded"
                                                    title="Make Regular User">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                                                </svg>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                        
                                        <!-- Ban/Unban -->
                                        <?php if($user['status'] === 'active'): ?>
                                        <form method="POST" onsubmit="return confirm('Ban this user?');">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="action" value="ban">
                                            <button type="submit" 
                                                    class="text-red-600 hover:text-red-700 p-1 hover:bg-red-50 rounded"
                                                    title="Ban User">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"></path>
                                                </svg>
                                            </button>
                                        </form>
                                        <?php else: ?>
                                        <form method="POST" onsubmit="return confirm('Unban this user?');">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="action" value="unban">
                                            <button type="submit" 
                                                    class="text-green-600 hover:text-green-700 p-1 hover:bg-green-50 rounded"
                                                    title="Unban User">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                                </svg>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                        
                                        <!-- Delete -->
                                        <?php if($user['id'] != $_SESSION['user_id']): ?>
                                        <form method="POST" onsubmit="return confirmDeleteUser(<?php echo $user['app_count'] ?? 0; ?>)">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <button type="submit" 
                                                    class="text-gray-600 hover:text-gray-700 p-1 hover:bg-gray-50 rounded"
                                                    title="Delete User">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                </svg>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-12">
                    <div class="text-gray-400 mb-4">
                        <svg class="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-600 mb-2">No users found</h3>
                    <p class="text-gray-500">Try selecting a different filter</p>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-6">
                <a href="dashboard.php" class="inline-flex items-center text-red-600 hover:text-red-700">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                    </svg>
                    Back to Dashboard
                </a>
            </div>
        </div>
    </div>
    
    <script>
        // Confirm user deletion
        function confirmDeleteUser(appCount) {
            if(appCount > 0) {
                alert('This user has ' + appCount + ' published apps. Please delete or reassign those apps first.');
                return false;
            }
            return confirm('Are you sure you want to delete this user? This action cannot be undone.');
        }
    </script>
</body>
</html>
<?php $conn->close(); ?>