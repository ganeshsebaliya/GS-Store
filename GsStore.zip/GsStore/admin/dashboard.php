<?php
require_once '../config.php';

// Check if user is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Get statistics
$stats_sql = "SELECT 
    (SELECT COUNT(*) FROM users) as total_users,
    (SELECT COUNT(*) FROM users WHERE role = 'publisher') as total_publishers,
    (SELECT COUNT(*) FROM apps) as total_apps,
    (SELECT COUNT(*) FROM apps WHERE status = 'pending') as pending_apps,
    (SELECT SUM(downloads) FROM apps) as total_downloads,
    (SELECT COUNT(*) FROM publisher_requests WHERE status = 'pending') as pending_requests";

$stats_result = $conn->query($stats_sql);
$stats = $stats_result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-red-600 to-pink-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <a href="../index.php" class="text-white font-bold text-xl">Gs Store</a>
                    <span class="text-white/80">|</span>
                    <span class="text-white font-medium">Admin Panel</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="../profile.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                    </a>
                    <a href="../logout.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <div class="container mx-auto px-4 py-6">
        <div class="flex flex-col md:flex-row gap-6">
            <!-- Sidebar -->
            <div class="md:w-1/4">
                <div class="bg-white rounded-2xl shadow-lg p-6 mb-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4">Admin Menu</h3>
                    <nav class="space-y-2">
                        <a href="dashboard.php" 
                           class="flex items-center space-x-3 p-3 rounded-lg bg-red-50 text-red-600 font-medium">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                            </svg>
                            <span>Dashboard</span>
                        </a>
                        <a href="apps.php" 
                           class="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 text-gray-700 hover:text-red-600 transition">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                            </svg>
                            <span>Manage Apps</span>
                        </a>
                        <a href="users.php" 
                           class="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 text-gray-700 hover:text-red-600 transition">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-7.645a4 4 0 11-5.5 5.5 4 4 0 015.5-5.5z"></path>
                            </svg>
                            <span>Manage Users</span>
                        </a>
                        <a href="categories.php" 
                           class="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 text-gray-700 hover:text-red-600 transition">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                            </svg>
                            <span>Categories</span>
                        </a>
                        <a href="banner.php" 
                           class="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 text-gray-700 hover:text-red-600 transition">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                            </svg>
                            <span>Featured Banner</span>
                        </a>
                        <a href="settings.php" 
                           class="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 text-gray-700 hover:text-red-600 transition">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                            </svg>
                            <span>Settings</span>
                        </a>
                    </nav>
                </div>
                
                <!-- Quick Stats -->
                <div class="bg-gradient-to-r from-red-500 to-pink-600 rounded-2xl shadow-lg p-6 text-white">
                    <h3 class="font-bold mb-4">Quick Overview</h3>
                    <div class="space-y-4">
                        <div>
                            <p class="text-sm opacity-80">Pending Apps</p>
                            <p class="text-2xl font-bold"><?php echo $stats['pending_apps']; ?></p>
                        </div>
                        <div>
                            <p class="text-sm opacity-80">Pending Requests</p>
                            <p class="text-2xl font-bold"><?php echo $stats['pending_requests']; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="md:w-3/4">
                <!-- Welcome -->
                <div class="bg-white rounded-2xl shadow-lg p-6 mb-6">
                    <h1 class="text-2xl font-bold text-gray-800 mb-2">Admin Dashboard</h1>
                    <p class="text-gray-600">Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</p>
                </div>
                
                <!-- Stats Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                    <div class="bg-white rounded-2xl shadow-lg p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">Total Users</p>
                                <p class="text-3xl font-bold text-gray-800"><?php echo $stats['total_users']; ?></p>
                            </div>
                            <div class="bg-blue-100 p-3 rounded-full">
                                <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-7.645a4 4 0 11-5.5 5.5 4 4 0 015.5-5.5z"></path>
                                </svg>
                            </div>
                        </div>
                        <a href="users.php" class="inline-block mt-4 text-red-600 hover:text-red-700 text-sm font-medium">
                            Manage Users →
                        </a>
                    </div>
                    
                    <div class="bg-white rounded-2xl shadow-lg p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">Publishers</p>
                                <p class="text-3xl font-bold text-gray-800"><?php echo $stats['total_publishers']; ?></p>
                            </div>
                            <div class="bg-green-100 p-3 rounded-full">
                                <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                                </svg>
                            </div>
                        </div>
                        <p class="mt-4 text-sm text-gray-500">Active publishers</p>
                    </div>
                    
                    <div class="bg-white rounded-2xl shadow-lg p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">Total Apps</p>
                                <p class="text-3xl font-bold text-gray-800"><?php echo $stats['total_apps']; ?></p>
                            </div>
                            <div class="bg-purple-100 p-3 rounded-full">
                                <svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                                </svg>
                            </div>
                        </div>
                        <a href="apps.php" class="inline-block mt-4 text-red-600 hover:text-red-700 text-sm font-medium">
                            Manage Apps →
                        </a>
                    </div>
                    
                    <div class="bg-white rounded-2xl shadow-lg p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">Pending Apps</p>
                                <p class="text-3xl font-bold text-gray-800"><?php echo $stats['pending_apps']; ?></p>
                            </div>
                            <div class="bg-yellow-100 p-3 rounded-full">
                                <svg class="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                        </div>
                        <a href="apps.php?status=pending" class="inline-block mt-4 text-red-600 hover:text-red-700 text-sm font-medium">
                            Review Now →
                        </a>
                    </div>
                    
                    <div class="bg-white rounded-2xl shadow-lg p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">Total Downloads</p>
                                <p class="text-3xl font-bold text-gray-800"><?php echo number_format($stats['total_downloads']); ?></p>
                            </div>
                            <div class="bg-indigo-100 p-3 rounded-full">
                                <svg class="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                                </svg>
                            </div>
                        </div>
                        <p class="mt-4 text-sm text-gray-500">All-time downloads</p>
                    </div>
                    
                    <div class="bg-white rounded-2xl shadow-lg p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">Pending Requests</p>
                                <p class="text-3xl font-bold text-gray-800"><?php echo $stats['pending_requests']; ?></p>
                            </div>
                            <div class="bg-pink-100 p-3 rounded-full">
                                <svg class="w-8 h-8 text-pink-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"></path>
                                </svg>
                            </div>
                        </div>
                        <p class="mt-4 text-sm text-gray-500">Publisher requests</p>
                    </div>
                </div>
                
                <!-- Charts -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                    <!-- App Status Chart -->
                    <div class="bg-white rounded-2xl shadow-lg p-6">
                        <h2 class="text-lg font-bold text-gray-800 mb-4">Apps by Status</h2>
                        <div class="h-64">
                            <canvas id="statusChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- Recent Activity -->
                    <div class="bg-white rounded-2xl shadow-lg p-6">
                        <h2 class="text-lg font-bold text-gray-800 mb-4">Recent Activity</h2>
                        <div class="space-y-4">
                            <?php
                            $activity_sql = "SELECT 'app' as type, a.title, a.status, a.created_at, u.name as user_name 
                                            FROM apps a 
                                            JOIN users u ON a.publisher_id = u.id 
                                            WHERE a.status = 'pending'
                                            UNION
                                            SELECT 'request' as type, 'Publisher Request' as title, pr.status, pr.created_at, u.name as user_name
                                            FROM publisher_requests pr
                                            JOIN users u ON pr.user_id = u.id
                                            WHERE pr.status = 'pending'
                                            ORDER BY created_at DESC 
                                            LIMIT 5";
                            $activity_result = $conn->query($activity_sql);
                            
                            if($activity_result->num_rows > 0):
                                while($activity = $activity_result->fetch_assoc()):
                                    $type_color = $activity['type'] === 'app' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800';
                                    $type_text = $activity['type'] === 'app' ? 'App' : 'Request';
                            ?>
                            <div class="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50">
                                <div>
                                    <div class="flex items-center space-x-2">
                                        <span class="px-2 py-1 rounded text-xs font-medium <?php echo $type_color; ?>">
                                            <?php echo $type_text; ?>
                                        </span>
                                        <h4 class="font-medium text-gray-800"><?php echo htmlspecialchars($activity['title']); ?></h4>
                                    </div>
                                    <p class="text-sm text-gray-500 mt-1">By <?php echo htmlspecialchars($activity['user_name']); ?></p>
                                </div>
                                <span class="text-sm text-gray-500"><?php echo date('M d', strtotime($activity['created_at'])); ?></span>
                            </div>
                            <?php endwhile; ?>
                            <?php else: ?>
                            <div class="text-center py-8">
                                <p class="text-gray-500">No pending activities</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="bg-white rounded-2xl shadow-lg p-6">
                    <h2 class="text-lg font-bold text-gray-800 mb-4">Quick Actions</h2>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <a href="apps.php?status=pending" 
                           class="group bg-gradient-to-r from-yellow-500 to-yellow-600 text-white p-6 rounded-xl shadow hover:shadow-lg transition">
                            <div class="flex items-center space-x-4">
                                <div class="bg-white/20 p-3 rounded-full">
                                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                                    </svg>
                                </div>
                                <div>
                                    <h3 class="text-lg font-bold">Review Apps</h3>
                                    <p class="text-sm opacity-90"><?php echo $stats['pending_apps']; ?> pending</p>
                                </div>
                            </div>
                        </a>
                        
                        <a href="users.php" 
                           class="group bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-xl shadow hover:shadow-lg transition">
                            <div class="flex items-center space-x-4">
                                <div class="bg-white/20 p-3 rounded-full">
                                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-7.645a4 4 0 11-5.5 5.5 4 4 0 015.5-5.5z"></path>
                                    </svg>
                                </div>
                                <div>
                                    <h3 class="text-lg font-bold">Manage Users</h3>
                                    <p class="text-sm opacity-90"><?php echo $stats['total_users']; ?> users</p>
                                </div>
                            </div>
                        </a>
                        
                        <a href="banner.php" 
                           class="group bg-gradient-to-r from-purple-500 to-purple-600 text-white p-6 rounded-xl shadow hover:shadow-lg transition">
                            <div class="flex items-center space-x-4">
                                <div class="bg-white/20 p-3 rounded-full">
                                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                    </svg>
                                </div>
                                <div>
                                    <h3 class="text-lg font-bold">Featured Banner</h3>
                                    <p class="text-sm opacity-90">App of the Week</p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // App Status Chart
        const statusCtx = document.getElementById('statusChart').getContext('2d');
        
        <?php
        // Get app status counts for chart
        $status_sql = "SELECT status, COUNT(*) as count FROM apps GROUP BY status";
        $status_result = $conn->query($status_sql);
        $status_data = [];
        while($row = $status_result->fetch_assoc()) {
            $status_data[$row['status']] = $row['count'];
        }
        ?>
        
        const statusChart = new Chart(statusCtx, {
            type: 'doughnut',
            data: {
                labels: ['Approved', 'Pending', 'Rejected'],
                datasets: [{
                    data: [
                        <?php echo $status_data['approved'] ?? 0; ?>,
                        <?php echo $status_data['pending'] ?? 0; ?>,
                        <?php echo $status_data['rejected'] ?? 0; ?>
                    ],
                    backgroundColor: [
                        '#10b981', // Green
                        '#f59e0b', // Yellow
                        '#ef4444'  // Red
                    ],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
        
        // Auto-refresh page every 60 seconds for live updates
        setTimeout(() => {
            location.reload();
        }, 60000);
    </script>
</body>
</html>
<?php 
$conn->close();
?>