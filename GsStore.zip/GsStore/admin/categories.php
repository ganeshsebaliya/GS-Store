<?php
require_once '../config.php';

// Check if user is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$message = '';
$error = '';

// Handle category actions
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    if(isset($_POST['add_category'])) {
        $name = trim($_POST['name']);
        
        if(empty($name)) {
            $error = "Category name is required";
        } else {
            // Check if category exists
            $check = $conn->prepare("SELECT id FROM categories WHERE name = ?");
            $check->bind_param("s", $name);
            $check->execute();
            
            if($check->get_result()->num_rows > 0) {
                $error = "Category already exists";
            } else {
                $insert = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
                $insert->bind_param("s", $name);
                
                if($insert->execute()) {
                    $message = "Category added successfully";
                } else {
                    $error = "Failed to add category";
                }
                $insert->close();
            }
            $check->close();
        }
    }
    
    if(isset($_POST['edit_category'])) {
        $id = intval($_POST['id']);
        $name = trim($_POST['name']);
        
        if(empty($name)) {
            $error = "Category name is required";
        } else {
            $update = $conn->prepare("UPDATE categories SET name = ? WHERE id = ?");
            $update->bind_param("si", $name, $id);
            
            if($update->execute()) {
                $message = "Category updated successfully";
            } else {
                $error = "Failed to update category";
            }
            $update->close();
        }
    }
    
    if(isset($_POST['delete_category'])) {
        $id = intval($_POST['id']);
        
        // Check if category has apps
        $check_apps = $conn->prepare("SELECT COUNT(*) as app_count FROM apps WHERE category_id = ?");
        $check_apps->bind_param("i", $id);
        $check_apps->execute();
        $result = $check_apps->get_result();
        $data = $result->fetch_assoc();
        
        if($data['app_count'] > 0) {
            $error = "Cannot delete category with apps. Please reassign apps first.";
        } else {
            $delete = $conn->prepare("DELETE FROM categories WHERE id = ?");
            $delete->bind_param("i", $id);
            
            if($delete->execute()) {
                $message = "Category deleted successfully";
            } else {
                $error = "Failed to delete category";
            }
            $delete->close();
        }
        $check_apps->close();
    }
}

// Fetch all categories
$categories_sql = "SELECT c.*, COUNT(a.id) as app_count 
                  FROM categories c 
                  LEFT JOIN apps a ON c.id = a.category_id 
                  GROUP BY c.id 
                  ORDER BY c.name";
$categories_result = $conn->query($categories_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-red-600 to-pink-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <a href="../index.php" class="text-white font-bold text-xl">Gs Store</a>
                    <span class="text-white/80">|</span>
                    <span class="text-white font-medium">Manage Categories</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </a>
                    <a href="../logout.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            <!-- Breadcrumb -->
            <div class="mb-6">
                <nav class="flex space-x-2 text-sm text-gray-600">
                    <a href="../index.php" class="hover:text-red-600">Home</a>
                    <span>/</span>
                    <a href="dashboard.php" class="hover:text-red-600">Admin</a>
                    <span>/</span>
                    <span class="text-gray-800 font-medium">Categories</span>
                </nav>
            </div>
            
            <!-- Messages -->
            <?php if($error): ?>
            <div class="mb-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>
            
            <?php if($message): ?>
            <div class="mb-6 p-4 bg-green-50 border border-green-200 text-green-700 rounded-xl">
                <?php echo htmlspecialchars($message); ?>
            </div>
            <?php endif; ?>
            
            <!-- Add Category Form -->
            <div class="bg-white rounded-2xl shadow-lg p-6 mb-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Add New Category</h2>
                <form method="POST" action="">
                    <div class="flex space-x-4">
                        <input type="text" name="name" required
                               class="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                               placeholder="Enter category name">
                        <button type="submit" name="add_category"
                                class="bg-gradient-to-r from-red-500 to-pink-600 text-white font-bold py-3 px-6 rounded-xl hover:shadow-lg transition">
                            Add Category
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- Categories List -->
            <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-xl font-bold text-gray-800">All Categories</h2>
                    <p class="text-sm text-gray-600">Manage app categories</p>
                </div>
                
                <?php if($categories_result->num_rows > 0): ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Apps</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php while($category = $categories_result->fetch_assoc()): ?>
                            <tr class="hover:bg-gray-50" id="category-<?php echo $category['id']; ?>">
                                <td class="px-6 py-4">
                                    <div class="font-medium text-gray-800"><?php echo htmlspecialchars($category['name']); ?></div>
                                    <div class="text-sm text-gray-500">ID: <?php echo $category['id']; ?></div>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                                        <?php echo $category['app_count']; ?> apps
                                    </span>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex items-center space-x-2">
                                        <button onclick="editCategory(<?php echo $category['id']; ?>, '<?php echo htmlspecialchars(addslashes($category['name'])); ?>')"
                                                class="text-blue-600 hover:text-blue-700 p-1 hover:bg-blue-50 rounded">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                            </svg>
                                        </button>
                                        <form method="POST" onsubmit="return confirmDeleteCategory(<?php echo $category['app_count']; ?>)">
                                            <input type="hidden" name="id" value="<?php echo $category['id']; ?>">
                                            <button type="submit" name="delete_category" 
                                                    class="text-red-600 hover:text-red-700 p-1 hover:bg-red-50 rounded">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                </svg>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-12">
                    <div class="text-gray-400 mb-4">
                        <svg class="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-600 mb-2">No categories found</h3>
                    <p class="text-gray-500">Add your first category using the form above</p>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Edit Modal -->
            <div id="editModal" class="fixed inset-0 z-50 bg-black/50 hidden">
                <div class="flex items-center justify-center min-h-screen p-4">
                    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md">
                        <div class="p-6">
                            <div class="flex justify-between items-center mb-6">
                                <h3 class="text-xl font-bold text-gray-800">Edit Category</h3>
                                <button onclick="closeEditModal()" 
                                        class="text-gray-400 hover:text-gray-600">
                                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                                    </svg>
                                </button>
                            </div>
                            
                            <form method="POST" action="" id="editForm">
                                <input type="hidden" name="id" id="editId">
                                <input type="hidden" name="edit_category" value="1">
                                
                                <div class="mb-6">
                                    <label class="block text-gray-700 text-sm font-medium mb-2">Category Name</label>
                                    <input type="text" name="name" id="editName" required
                                           class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent">
                                </div>
                                
                                <div class="flex space-x-3">
                                    <button type="button" 
                                            onclick="closeEditModal()" 
                                            class="flex-1 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition">
                                        Cancel
                                    </button>
                                    <button type="submit" 
                                            class="flex-1 py-3 bg-gradient-to-r from-red-500 to-pink-600 text-white font-semibold rounded-xl hover:shadow-lg transition">
                                        Update Category
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Back to Dashboard -->
            <div class="mt-6">
                <a href="dashboard.php" class="inline-flex items-center text-red-600 hover:text-red-700">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                    </svg>
                    Back to Dashboard
                </a>
            </div>
        </div>
    </div>
    
    <script>
        // Edit category
        function editCategory(id, name) {
            document.getElementById('editId').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('editModal').classList.remove('hidden');
        }
        
        // Close edit modal
        function closeEditModal() {
            document.getElementById('editModal').classList.add('hidden');
        }
        
        // Confirm category deletion
        function confirmDeleteCategory(appCount) {
            if(appCount > 0) {
                alert('This category has ' + appCount + ' apps. Please reassign or delete those apps first.');
                return false;
            }
            return confirm('Are you sure you want to delete this category?');
        }
        
        // Close modal on outside click
        document.getElementById('editModal').addEventListener('click', function(e) {
            if(e.target === this) {
                closeEditModal();
            }
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>