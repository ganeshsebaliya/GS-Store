<?php
require_once '../config.php';

// Check if user is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$message = '';
$error = '';

// Fetch current settings
$settings_sql = "SELECT * FROM settings WHERE id = 1";
$settings_result = $conn->query($settings_sql);
$settings = $settings_result->fetch_assoc();

// Fetch approved apps for dropdown
$apps_sql = "SELECT id, title FROM apps WHERE status = 'approved' ORDER BY title";
$apps_result = $conn->query($apps_sql);

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $featured_app_id = intval($_POST['featured_app_id']);
    $banner_image = $settings['banner_image']; // Keep existing unless new uploaded
    
    // Handle banner image upload
    if(isset($_FILES['banner_image']) && $_FILES['banner_image']['error'] === 0) {
        $file = $_FILES['banner_image'];
        
        // Validate file
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
        $max_size = 5 * 1024 * 1024; // 5MB
        
        if(in_array($file['type'], $allowed_types) && $file['size'] <= $max_size) {
            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'banner_' . time() . '.' . $extension;
            $target_file = '../assets/uploads/banners/' . $filename;
            
            // Delete old banner if exists
            if(!empty($settings['banner_image'])) {
                $old_file = '../assets/uploads/banners/' . $settings['banner_image'];
                if(file_exists($old_file)) {
                    unlink($old_file);
                }
            }
            
            // Move uploaded file
            if(move_uploaded_file($file['tmp_name'], $target_file)) {
                $banner_image = $filename;
            } else {
                $error = "Failed to upload banner image";
            }
        } else {
            $error = "Invalid banner image. Please upload JPEG, PNG or GIF image (max 5MB)";
        }
    }
    
    if(empty($error)) {
        // Unfeature all apps
        $unfeature = $conn->prepare("UPDATE apps SET is_featured = 0");
        $unfeature->execute();
        $unfeature->close();
        
        // Feature selected app
        if($featured_app_id > 0) {
            $feature = $conn->prepare("UPDATE apps SET is_featured = 1 WHERE id = ?");
            $feature->bind_param("i", $featured_app_id);
            $feature->execute();
            $feature->close();
        }
        
        // Update settings
        $update = $conn->prepare("UPDATE settings SET featured_app_id = ?, banner_image = ? WHERE id = 1");
        $update->bind_param("is", $featured_app_id, $banner_image);
        
        if($update->execute()) {
            $message = "Featured app and banner updated successfully!";
            // Refresh settings
            $settings['featured_app_id'] = $featured_app_id;
            $settings['banner_image'] = $banner_image;
        } else {
            $error = "Failed to update settings";
        }
        $update->close();
    }
}

// Get current featured app info
$current_featured = null;
if($settings['featured_app_id']) {
    $featured_sql = "SELECT title FROM apps WHERE id = ?";
    $featured_stmt = $conn->prepare($featured_sql);
    $featured_stmt->bind_param("i", $settings['featured_app_id']);
    $featured_stmt->execute();
    $featured_result = $featured_stmt->get_result();
    $current_featured = $featured_result->fetch_assoc();
    $featured_stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Featured Banner - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-red-600 to-pink-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <a href="../index.php" class="text-white font-bold text-xl">Gs Store</a>
                    <span class="text-white/80">|</span>
                    <span class="text-white font-medium">Featured Banner</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </a>
                    <a href="../logout.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            <!-- Breadcrumb -->
            <div class="mb-6">
                <nav class="flex space-x-2 text-sm text-gray-600">
                    <a href="../index.php" class="hover:text-red-600">Home</a>
                    <span>/</span>
                    <a href="dashboard.php" class="hover:text-red-600">Admin</a>
                    <span>/</span>
                    <span class="text-gray-800 font-medium">Featured Banner</span>
                </nav>
            </div>
            
            <!-- Current Status -->
            <div class="bg-white rounded-2xl shadow-lg p-6 mb-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Current Featured App</h2>
                
                <?php if($settings['featured_app_id'] && $settings['banner_image'] && $current_featured): ?>
                <div class="flex flex-col md:flex-row items-center md:items-start space-y-6 md:space-y-0 md:space-x-6">
                    <!-- Banner Preview -->
                    <div class="md:w-2/3">
                        <div class="relative rounded-xl overflow-hidden shadow-lg">
                            <img src="../assets/uploads/banners/<?php echo htmlspecialchars($settings['banner_image']); ?>" 
                                 alt="Featured Banner"
                                 class="w-full h-48 md:h-64 object-cover">
                            <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                            <div class="absolute bottom-4 left-6 text-white">
                                <h3 class="text-xl font-bold">App of the Week</h3>
                                <p class="text-sm opacity-90"><?php echo htmlspecialchars($current_featured['title']); ?></p>
                            </div>
                        </div>
                        <p class="text-sm text-gray-500 mt-2 text-center">This banner appears on the homepage</p>
                    </div>
                    
                    <!-- App Info -->
                    <div class="md:w-1/3">
                        <div class="bg-blue-50 border border-blue-200 rounded-xl p-4">
                            <h4 class="font-bold text-blue-800 mb-2">Featured App Details</h4>
                            <p class="text-blue-700"><strong>App:</strong> <?php echo htmlspecialchars($current_featured['title']); ?></p>
                            <p class="text-blue-700"><strong>App ID:</strong> <?php echo $settings['featured_app_id']; ?></p>
                            <p class="text-blue-700"><strong>Banner File:</strong> <?php echo htmlspecialchars($settings['banner_image']); ?></p>
                            <div class="mt-4">
                                <a href="../app.php?id=<?php echo $settings['featured_app_id']; ?>" 
                                   class="inline-block text-blue-600 hover:text-blue-700 font-medium">
                                    View App Page →
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="text-center py-8">
                    <div class="text-gray-400 mb-4">
                        <svg class="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-600 mb-2">No Featured App Set</h3>
                    <p class="text-gray-500">The "App of the Week" section is not visible on homepage</p>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Update Form -->
            <div class="bg-white rounded-2xl shadow-xl p-6">
                <h2 class="text-2xl font-bold text-gray-800 mb-2">Update Featured Banner</h2>
                <p class="text-gray-600 mb-6">Set the App of the Week and upload banner image</p>
                
                <?php if($error): ?>
                <div class="mb-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl">
                    <?php echo htmlspecialchars($error); ?>
                </div>
                <?php endif; ?>
                
                <?php if($message): ?>
                <div class="mb-6 p-4 bg-green-50 border border-green-200 text-green-700 rounded-xl">
                    <?php echo htmlspecialchars($message); ?>
                </div>
                <?php endif; ?>
                
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="space-y-6">
                        <!-- Select App -->
                        <div>
                            <label class="block text-gray-700 text-sm font-medium mb-2">Select Featured App *</label>
                            <select name="featured_app_id" required
                                    class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent">
                                <option value="0">-- No Featured App (Hide Banner) --</option>
                                <?php while($app = $apps_result->fetch_assoc()): ?>
                                <option value="<?php echo $app['id']; ?>" <?php echo $settings['featured_app_id'] == $app['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($app['title']); ?> (ID: <?php echo $app['id']; ?>)
                                </option>
                                <?php endwhile; ?>
                            </select>
                            <p class="text-sm text-gray-500 mt-2">Select "No Featured App" to hide the banner from homepage</p>
                        </div>
                        
                        <!-- Banner Image -->
                        <div>
                            <label class="block text-gray-700 text-sm font-medium mb-2">Banner Image</label>
                            
                            <?php if($settings['banner_image']): ?>
                            <div class="mb-4 p-4 border border-gray-200 rounded-xl">
                                <p class="text-sm text-gray-600 mb-2">Current Banner:</p>
                                <img src="../assets/uploads/banners/<?php echo htmlspecialchars($settings['banner_image']); ?>" 
                                     alt="Current Banner"
                                     class="w-full max-w-md h-32 object-cover rounded-lg">
                                <p class="text-xs text-gray-500 mt-2"><?php echo htmlspecialchars($settings['banner_image']); ?></p>
                            </div>
                            <?php endif; ?>
                            
                            <div class="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-red-400 transition">
                                <input type="file" name="banner_image" accept="image/png, image/jpeg, image/jpg, image/gif" 
                                       class="hidden" id="bannerInput" onchange="previewBanner(event)">
                                <label for="bannerInput" class="cursor-pointer">
                                    <div class="mx-auto w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center mb-3">
                                        <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                        </svg>
                                    </div>
                                    <p class="text-sm text-gray-600">Click to upload new banner</p>
                                    <p class="text-xs text-gray-500 mt-1">JPEG, PNG or GIF, max 5MB</p>
                                    <p class="text-xs text-gray-500 mt-1">Recommended size: 1200×400 pixels</p>
                                </label>
                            </div>
                            <div id="bannerPreview" class="mt-4 hidden">
                                <p class="text-sm text-gray-600 mb-2">New banner preview:</p>
                                <img id="bannerPreviewImg" class="w-full max-w-md h-32 object-cover rounded-lg border">
                            </div>
                            <p class="text-sm text-gray-500 mt-2">Leave empty to keep current banner</p>
                        </div>
                        
                        <!-- Submit -->
                        <div class="pt-6 border-t">
                            <div class="flex justify-between items-center">
                                <a href="dashboard.php" class="text-gray-600 hover:text-gray-800 font-medium">
                                    ← Back to Dashboard
                                </a>
                                <button type="submit" 
                                        class="bg-gradient-to-r from-red-500 to-pink-600 text-white font-bold py-3 px-8 rounded-xl hover:shadow-lg transition-transform active:scale-95">
                                    Update Featured Banner
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Instructions -->
            <div class="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-xl">
                <div class="flex items-start space-x-3">
                    <svg class="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <div>
                        <h4 class="font-medium text-blue-800">How it works</h4>
                        <ul class="text-sm text-blue-700 mt-2 space-y-1 list-disc ml-5">
                            <li>The featured app will be displayed prominently on the homepage</li>
                            <li>Only one app can be featured at a time</li>
                            <li>If no app is selected, the banner section will be hidden</li>
                            <li>The banner image should be eye-catching and high-quality</li>
                            <li>Featured apps get special promotion and increased visibility</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Preview banner image
        function previewBanner(event) {
            const input = event.target;
            const preview = document.getElementById('bannerPreview');
            const img = document.getElementById('bannerPreviewImg');
            
            if(input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    img.src = e.target.result;
                    preview.classList.remove('hidden');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        // Confirm before clearing featured app
        const form = document.querySelector('form');
        const select = form.querySelector('select[name="featured_app_id"]');
        
        select.addEventListener('change', function() {
            if(this.value === '0') {
                if(!confirm('This will hide the featured banner from homepage. Continue?')) {
                    this.value = '<?php echo $settings["featured_app_id"] ?? 0; ?>';
                }
            }
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>