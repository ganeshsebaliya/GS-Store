<?php
require_once 'config.php';

// Redirect if not logged in
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// Fetch user details
$user_sql = "SELECT name, email, created_at FROM users WHERE id = ?";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();
$user_stmt->close();

// Fetch downloaded apps
$downloads_sql = "SELECT d.created_at, a.id, a.title, a.icon 
                  FROM downloads d 
                  JOIN apps a ON d.app_id = a.id 
                  WHERE d.user_id = ? 
                  ORDER BY d.created_at DESC 
                  LIMIT 20";
$downloads_stmt = $conn->prepare($downloads_sql);
$downloads_stmt->bind_param("i", $user_id);
$downloads_stmt->execute();
$downloads_result = $downloads_stmt->get_result();

// Handle publisher request
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_publisher'])) {
    // Check if already requested
    $check_request = $conn->prepare("SELECT id FROM publisher_requests WHERE user_id = ? AND status = 'pending'");
    $check_request->bind_param("i", $user_id);
    $check_request->execute();
    
    if($check_request->get_result()->num_rows === 0) {
        $insert_request = $conn->prepare("INSERT INTO publisher_requests (user_id) VALUES (?)");
        $insert_request->bind_param("i", $user_id);
        $insert_request->execute();
        $insert_request->close();
        $message = "Publisher request submitted successfully!";
    } else {
        $message = "You already have a pending request.";
    }
    $check_request->close();
}

// Check if user has pending publisher request
$pending_request = false;
if($role === 'user') {
    $check_pending = $conn->prepare("SELECT id FROM publisher_requests WHERE user_id = ? AND status = 'pending'");
    $check_pending->bind_param("i", $user_id);
    $check_pending->execute();
    $pending_request = $check_pending->get_result()->num_rows > 0;
    $check_pending->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .profile-gradient { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .btn-click { transition: transform 0.2s; }
        .btn-click:active { transform: scale(0.95); }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <a href="index.php" class="text-white font-bold text-xl">Gs Store | Build With Satya</a>
                <a href="logout.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                    </svg>
                </a>
            </div>
        </div>
    </header>
    
    <main class="container mx-auto px-4 py-6 pb-24">
        <!-- User Profile Card -->
        <div class="profile-gradient rounded-2xl shadow-xl p-6 mb-6 text-white">
            <div class="flex items-center space-x-4">
                <div class="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
                    <span class="text-2xl font-bold"><?php echo strtoupper(substr($user['name'], 0, 1)); ?></span>
                </div>
                <div>
                    <h1 class="text-2xl font-bold"><?php echo htmlspecialchars($user['name']); ?></h1>
                    <p class="opacity-90"><?php echo htmlspecialchars($user['email']); ?></p>
                    <p class="text-sm opacity-80 mt-1">Member since <?php echo date('F Y', strtotime($user['created_at'])); ?></p>
                </div>
            </div>
        </div>
        
        <!-- Role & Actions -->
        <div class="bg-white rounded-2xl shadow-lg p-6 mb-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Account Status</h2>
            
            <div class="mb-6">
                <div class="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium
                    <?php echo $role === 'admin' ? 'bg-red-100 text-red-800' : 
                           ($role === 'publisher' ? 'bg-blue-100 text-blue-800' : 
                           'bg-gray-100 text-gray-800'); ?>">
                    <?php echo ucfirst($role); ?> Account
                </div>
            </div>
            
            <div class="space-y-3">
                <?php if($role === 'user'): ?>
                    <?php if($pending_request): ?>
                    <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <p class="text-yellow-800">Your publisher request is pending approval.</p>
                    </div>
                    <?php else: ?>
                    <form method="POST">
                        <button type="submit" name="request_publisher" 
                                class="w-full btn-click bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold py-3 px-6 rounded-xl hover:shadow-lg transition text-center">
                            Become a Publisher
                        </button>
                        <p class="text-sm text-gray-500 mt-2 text-center">Request to upload and manage your own apps</p>
                    </form>
                    <?php endif; ?>
                <?php elseif($role === 'publisher'): ?>
                    <a href="publisher/dashboard.php" 
                       class="block btn-click bg-gradient-to-r from-green-500 to-emerald-600 text-white font-semibold py-3 px-6 rounded-xl hover:shadow-lg transition text-center">
                        Go to Publisher Dashboard
                    </a>
                    <p class="text-sm text-gray-500 mt-2 text-center">Manage your apps and view analytics</p>
                <?php endif; ?>
                
                <?php if($role === 'admin'): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <a href="admin/dashboard.php" 
                       class="block btn-click bg-gradient-to-r from-red-500 to-pink-600 text-white font-semibold py-3 px-6 rounded-xl hover:shadow-lg transition text-center">
                        Go to Admin Dashboard
                    </a>
                    <a href="publisher/dashboard.php" 
                       class="block btn-click bg-gradient-to-r from-green-500 to-emerald-600 text-white font-semibold py-3 px-6 rounded-xl hover:shadow-lg transition text-center">
                        Go to Seller Dashboard
                    </a>
                </div>
                <p class="text-sm text-gray-500 mt-2 text-center">You have access to both admin and publisher panels</p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Downloaded Apps -->
        <div class="bg-white rounded-2xl shadow-lg p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-gray-800">Recently Downloaded</h2>
                <span class="text-sm text-gray-500"><?php echo $downloads_result->num_rows; ?> apps</span>
            </div>
            
            <?php if($downloads_result->num_rows > 0): ?>
            <div class="space-y-4">
                <?php while($download = $downloads_result->fetch_assoc()): ?>
                <a href="app.php?id=<?php echo $download['id']; ?>" 
                   class="flex items-center space-x-4 p-3 rounded-lg hover:bg-gray-50 transition">
                    <img src="assets/uploads/icons/<?php echo htmlspecialchars($download['icon']); ?>" 
                         alt="<?php echo htmlspecialchars($download['title']); ?>"
                         class="w-12 h-12 rounded-xl object-cover">
                    <div class="flex-1">
                        <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($download['title']); ?></h3>
                        <p class="text-sm text-gray-500">Downloaded <?php echo date('M d', strtotime($download['created_at'])); ?></p>
                    </div>
                    <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                </a>
                <?php endwhile; ?>
            </div>
            <?php else: ?>
            <div class="text-center py-8">
                <div class="text-gray-400 mb-4">
                    <svg class="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10"></path>
                    </svg>
                </div>
                <p class="text-gray-500">You haven't downloaded any apps yet</p>
                <a href="category.php" class="inline-block mt-4 text-blue-600 hover:text-blue-700 font-medium">
                    Browse Apps →
                </a>
            </div>
            <?php endif; ?>
        </div>
    </main>
    
    <!-- Footer Navigation -->
    <footer class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-3 z-40">
        <div class="container mx-auto px-4">
            <div class="flex justify-around">
                <a href="index.php" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
                    <div class="p-2 rounded-full hover:bg-blue-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </div>
                    <span class="text-xs mt-1">Home</span>
                </a>
                
                <a href="category.php" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
                    <div class="p-2 rounded-full hover:bg-blue-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                        </svg>
                    </div>
                    <span class="text-xs mt-1">Categories</span>
                </a>
                
                <a href="profile.php" class="flex flex-col items-center text-blue-600">
                    <div class="p-2 rounded-full bg-blue-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                    </div>
                    <span class="text-xs mt-1">Profile</span>
                </a>
            </div>
        </div>
    </footer>
    
    <script>
        // Button click animation
        document.querySelectorAll('.btn-click').forEach(btn => {
            btn.addEventListener('click', function() {
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 200);
            });
        });
        
        // Footer button animation
        document.querySelectorAll('footer a').forEach(link => {
            link.addEventListener('click', function(e) {
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 200);
            });
        });
        
        // Show message if exists
        <?php if(isset($message)): ?>
        alert("<?php echo $message; ?>");
        <?php endif; ?>
    </script>
</body>
</html>
<?php 
$downloads_stmt->close();
$conn->close();
?>