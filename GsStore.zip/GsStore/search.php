<?php
require_once 'config.php';

$query = isset($_GET['q']) ? trim($_GET['q']) : '';

if(strlen($query) < 2) {
    echo '<div class="p-4 text-center text-gray-500">Type at least 2 characters to search</div>';
    exit();
}

// Prepare search query with LIKE
$search_sql = "SELECT a.id, a.title, a.icon, c.name as category_name 
               FROM apps a 
               LEFT JOIN categories c ON a.category_id = c.id 
               WHERE a.status = 'approved' 
               AND (a.title LIKE ? OR a.description LIKE ? OR c.name LIKE ?)
               ORDER BY a.downloads DESC 
               LIMIT 10";

$search_term = "%{$query}%";
$search_stmt = $conn->prepare($search_sql);
$search_stmt->bind_param("sss", $search_term, $search_term, $search_term);
$search_stmt->execute();
$search_result = $search_stmt->get_result();

if($search_result->num_rows === 0) {
    echo '<div class="p-6 text-center">
            <div class="text-gray-400 mb-3">
                <svg class="w-12 h-12 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
            </div>
            <p class="text-gray-600">No apps found for "' . htmlspecialchars($query) . '"</p>
            <p class="text-sm text-gray-500 mt-1">Try different keywords</p>
        </div>';
} else {
    while($app = $search_result->fetch_assoc()) {
        echo '<a href="app.php?id=' . $app['id'] . '" class="block p-4 hover:bg-gray-50 border-b border-gray-100 last:border-0 transition">
                <div class="flex items-center space-x-4">
                    <img src="assets/uploads/icons/' . htmlspecialchars($app['icon']) . '" 
                         alt="' . htmlspecialchars($app['title']) . '"
                         class="w-12 h-12 rounded-xl object-cover">
                    <div class="flex-1">
                        <h3 class="font-semibold text-gray-800">' . htmlspecialchars($app['title']) . '</h3>
                        ' . ($app['category_name'] ? '<p class="text-sm text-gray-500">' . htmlspecialchars($app['category_name']) . '</p>' : '') . '
                    </div>
                    <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                </div>
            </a>';
    }
}

$search_stmt->close();
$conn->close();
?>