<?php
require_once 'config.php';

// Redirect if already logged in
if(isset($_SESSION['user_id'])) {
    header("Location: profile.php");
    exit();
}

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validation
    if(empty($name) || empty($email) || empty($password)) {
        $error = "Please fill in all fields";
    } elseif($password !== $confirm_password) {
        $error = "Passwords do not match";
    } elseif(strlen($password) < 6) {
        $error = "Password must be at least 6 characters";
    } else {
        // Check if email exists
        $check_sql = "SELECT id FROM users WHERE email = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if($check_result->num_rows > 0) {
            $error = "Email already registered";
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert user
            $insert_sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bind_param("sss", $name, $email, $hashed_password);
            
            if($insert_stmt->execute()) {
                $success = "Account created successfully! You can now login.";
                // Clear form
                $name = $email = '';
            } else {
                $error = "Registration failed. Please try again.";
            }
            $insert_stmt->close();
        }
        $check_stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .register-gradient { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .input-focus:focus { box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1); }
        .password-strength { height: 4px; border-radius: 2px; transition: all 0.3s; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md">
        <!-- Logo/Header -->
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">Gs Store</h1>
            <p class="text-gray-600 mt-2">Build With Satya</p>
        </div>
        
        <!-- Register Card -->
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <!-- Gradient Header -->
            <div class="register-gradient p-6 text-white text-center">
                <h2 class="text-2xl font-bold">Create Account</h2>
                <p class="opacity-90 mt-1">Join Gs Store today</p>
            </div>
            
            <!-- Form -->
            <div class="p-6">
                <?php if($error): ?>
                <div class="mb-4 p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl">
                    <?php echo htmlspecialchars($error); ?>
                </div>
                <?php endif; ?>
                
                <?php if($success): ?>
                <div class="mb-4 p-4 bg-green-50 border border-green-200 text-green-700 rounded-xl">
                    <?php echo htmlspecialchars($success); ?>
                </div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-medium mb-2">Full Name</label>
                        <input type="text" name="name" required value="<?php echo isset($name) ? htmlspecialchars($name) : ''; ?>"
                               class="w-full px-4 py-3 border border-gray-300 rounded-xl input-focus focus:outline-none focus:border-blue-500 transition"
                               placeholder="John Doe">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-medium mb-2">Email Address</label>
                        <input type="email" name="email" required value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>"
                               class="w-full px-4 py-3 border border-gray-300 rounded-xl input-focus focus:outline-none focus:border-blue-500 transition"
                               placeholder="you@example.com">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-medium mb-2">Password</label>
                        <input type="password" name="password" required id="password"
                               class="w-full px-4 py-3 border border-gray-300 rounded-xl input-focus focus:outline-none focus:border-blue-500 transition"
                               placeholder="••••••••"
                               oninput="checkPasswordStrength(this.value)">
                        <div class="mt-2">
                            <div class="flex space-x-1 mb-1">
                                <div id="strength1" class="password-strength flex-1 bg-gray-200"></div>
                                <div id="strength2" class="password-strength flex-1 bg-gray-200"></div>
                                <div id="strength3" class="password-strength flex-1 bg-gray-200"></div>
                                <div id="strength4" class="password-strength flex-1 bg-gray-200"></div>
                            </div>
                            <p id="strengthText" class="text-xs text-gray-500">Password strength</p>
                        </div>
                    </div>
                    
                    <div class="mb-6">
                        <label class="block text-gray-700 text-sm font-medium mb-2">Confirm Password</label>
                        <input type="password" name="confirm_password" required id="confirmPassword"
                               class="w-full px-4 py-3 border border-gray-300 rounded-xl input-focus focus:outline-none focus:border-blue-500 transition"
                               placeholder="••••••••"
                               oninput="checkPasswordMatch()">
                        <p id="passwordMatch" class="text-xs mt-2"></p>
                    </div>
                    
                    <button type="submit" 
                            class="w-full register-gradient text-white font-bold py-3 px-4 rounded-xl hover:shadow-lg transition-transform active:scale-95">
                        Create Account
                    </button>
                    
                    <div class="mt-4 text-xs text-gray-500 text-center">
                        By creating an account, you agree to our 
                        <a href="#" class="text-blue-600 hover:text-blue-700">Terms</a> and 
                        <a href="#" class="text-blue-600 hover:text-blue-700">Privacy Policy</a>
                    </div>
                </form>
                
                <div class="mt-6 text-center">
                    <p class="text-gray-600">Already have an account?</p>
                    <a href="login.php" class="inline-block mt-2 text-blue-600 font-semibold hover:text-blue-700">
                        Sign In →
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Back to home -->
        <div class="text-center mt-6">
            <a href="index.php" class="text-gray-600 hover:text-gray-800 flex items-center justify-center">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                </svg>
                Back to Home
            </a>
        </div>
    </div>
    
    <script>
        // Password strength checker
        function checkPasswordStrength(password) {
            let strength = 0;
            const strengthBars = [
                document.getElementById('strength1'),
                document.getElementById('strength2'),
                document.getElementById('strength3'),
                document.getElementById('strength4')
            ];
            const strengthText = document.getElementById('strengthText');
            
            // Reset bars
            strengthBars.forEach(bar => {
                bar.style.backgroundColor = '#e5e7eb';
            });
            
            if(password.length >= 6) strength++;
            if(password.length >= 8) strength++;
            if(/[A-Z]/.test(password) && /[a-z]/.test(password)) strength++;
            if(/\d/.test(password)) strength++;
            if(/[!@#$%^&*]/.test(password)) strength++;
            
            // Cap at 4
            strength = Math.min(strength, 4);
            
            // Color bars
            for(let i = 0; i < strength; i++) {
                if(strength === 1) {
                    strengthBars[i].style.backgroundColor = '#ef4444'; // Red
                } else if(strength === 2) {
                    strengthBars[i].style.backgroundColor = '#f59e0b'; // Yellow
                } else if(strength === 3) {
                    strengthBars[i].style.backgroundColor = '#10b981'; // Green
                } else if(strength === 4) {
                    strengthBars[i].style.backgroundColor = '#059669'; // Dark Green
                }
            }
            
            // Update text
            const texts = ['Very Weak', 'Weak', 'Fair', 'Strong', 'Very Strong'];
            strengthText.textContent = `Password strength: ${texts[strength]}`;
            strengthText.className = `text-xs mt-2 ${strength >= 3 ? 'text-green-600' : 'text-red-600'}`;
        }
        
        // Password match checker
        function checkPasswordMatch() {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const matchText = document.getElementById('passwordMatch');
            
            if(confirmPassword === '') {
                matchText.textContent = '';
                matchText.className = 'text-xs mt-2';
                return;
            }
            
            if(password === confirmPassword) {
                matchText.textContent = '✓ Passwords match';
                matchText.className = 'text-xs mt-2 text-green-600';
            } else {
                matchText.textContent = '✗ Passwords do not match';
                matchText.className = 'text-xs mt-2 text-red-600';
            }
        }
        
        // Form submission animation
        const form = document.querySelector('form');
        const submitBtn = form.querySelector('button[type="submit"]');
        
        form.addEventListener('submit', function() {
            submitBtn.disabled = true;
            submitBtn.innerHTML = 'Creating Account...';
            submitBtn.classList.add('opacity-75');
        });
        
        // Input focus effects
        const inputs = document.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('ring-2', 'ring-blue-200');
            });
            input.addEventListener('blur', function() {
                this.parentElement.classList.remove('ring-2', 'ring-blue-200');
            });
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>