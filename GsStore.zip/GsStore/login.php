<?php
require_once 'config.php';

// Redirect if already logged in
if(isset($_SESSION['user_id'])) {
    header("Location: profile.php");
    exit();
}

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    if(empty($email) || empty($password)) {
        $error = "Please fill in all fields";
    } else {
        $sql = "SELECT id, name, email, password, role, status FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Check if user is banned
            if($user['status'] === 'banned') {
                $error = "Your account has been banned. Please contact support.";
            } elseif(password_verify($password, $user['password'])) {
                // Regenerate session ID for security
                session_regenerate_id(true);
                
                // Set session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['role'] = $user['role'];
                
                // Update last login (optional)
                // $update_sql = "UPDATE users SET last_login = NOW() WHERE id = ?";
                // $update_stmt = $conn->prepare($update_sql);
                // $update_stmt->bind_param("i", $user['id']);
                // $update_stmt->execute();
                // $update_stmt->close();
                
                // Redirect based on role
                if($user['role'] === 'admin') {
                    header("Location: admin/dashboard.php");
                } elseif($user['role'] === 'publisher') {
                    header("Location: publisher/dashboard.php");
                } else {
                    header("Location: profile.php");
                }
                exit();
            } else {
                $error = "Invalid email or password";
            }
        } else {
            $error = "Invalid email or password";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .login-gradient { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .input-focus:focus { box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1); }
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md">
        <!-- Logo/Header -->
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-gray-800">Gs Store</h1>
            <p class="text-gray-600 mt-2">Build With Satya</p>
        </div>
        
        <!-- Login Card -->
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <!-- Gradient Header -->
            <div class="login-gradient p-6 text-white text-center">
                <h2 class="text-2xl font-bold">Welcome Back</h2>
                <p class="opacity-90 mt-1">Sign in to your account</p>
            </div>
            
            <!-- Form -->
            <div class="p-6">
                <?php if($error): ?>
                <div class="mb-4 p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl">
                    <?php echo htmlspecialchars($error); ?>
                </div>
                <?php endif; ?>
                
                <?php if($success): ?>
                <div class="mb-4 p-4 bg-green-50 border border-green-200 text-green-700 rounded-xl">
                    <?php echo htmlspecialchars($success); ?>
                </div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-medium mb-2">Email Address</label>
                        <input type="email" name="email" required
                               class="w-full px-4 py-3 border border-gray-300 rounded-xl input-focus focus:outline-none focus:border-blue-500 transition"
                               placeholder="you@example.com">
                    </div>
                    
                    <div class="mb-6">
                        <label class="block text-gray-700 text-sm font-medium mb-2">Password</label>
                        <input type="password" name="password" required
                               class="w-full px-4 py-3 border border-gray-300 rounded-xl input-focus focus:outline-none focus:border-blue-500 transition"
                               placeholder="••••••••">
                        <div class="text-right mt-2">
                            <a href="#" class="text-sm text-blue-600 hover:text-blue-700">Forgot password?</a>
                        </div>
                    </div>
                    
                    <button type="submit" 
                            class="w-full login-gradient text-white font-bold py-3 px-4 rounded-xl hover:shadow-lg transition-transform active:scale-95">
                        Sign In
                    </button>
                </form>
                
                <div class="mt-6 text-center">
                    <p class="text-gray-600">Don't have an account?</p>
                    <a href="register.php" class="inline-block mt-2 text-blue-600 font-semibold hover:text-blue-700">
                        Create Account →
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Back to home -->
        <div class="text-center mt-6">
            <a href="index.php" class="text-gray-600 hover:text-gray-800 flex items-center justify-center">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                </svg>
                Back to Home
            </a>
        </div>
    </div>
    
    <script>
        // Form submission animation
        const form = document.querySelector('form');
        const submitBtn = form.querySelector('button[type="submit"]');
        
        form.addEventListener('submit', function() {
            submitBtn.disabled = true;
            submitBtn.innerHTML = 'Signing in...';
            submitBtn.classList.add('opacity-75');
        });
        
        // Input focus effects
        const inputs = document.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('ring-2', 'ring-blue-200');
            });
            input.addEventListener('blur', function() {
                this.parentElement.classList.remove('ring-2', 'ring-blue-200');
            });
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>