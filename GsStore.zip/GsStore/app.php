<?php
require_once 'config.php';

if(!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$app_id = intval($_GET['id']);

// Check if user is admin/publisher for preview access
$user_access = false;
if(isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $role = $_SESSION['role'] ?? 'user';
    $user_access = ($role === 'admin' || $role === 'publisher');
}

// Fetch app details
$app_sql = "SELECT a.*, c.name as category_name, u.name as publisher_name, 
                   AVG(r.rating) as avg_rating, COUNT(r.id) as review_count
            FROM apps a 
            LEFT JOIN categories c ON a.category_id = c.id 
            LEFT JOIN users u ON a.publisher_id = u.id 
            LEFT JOIN reviews r ON a.id = r.app_id 
            WHERE a.id = ?";
            
if(!$user_access) {
    $app_sql .= " AND a.status = 'approved'";
}

$app_stmt = $conn->prepare($app_sql);
$app_stmt->bind_param("i", $app_id);
$app_stmt->execute();
$app_result = $app_stmt->get_result();

if($app_result->num_rows === 0) {
    header("Location: index.php");
    exit();
}

$app = $app_result->fetch_assoc();
$app_stmt->close();

// Handle download tracking
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download'])) {
    // Insert download log
    $user_id_val = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : NULL;
    $ip_address = $_SERVER['REMOTE_ADDR'];
    
    $download_log = $conn->prepare("INSERT INTO downloads (user_id, app_id, ip_address) VALUES (?, ?, ?)");
    $download_log->bind_param("iis", $user_id_val, $app_id, $ip_address);
    $download_log->execute();
    $download_log->close();
    
    // Increment download count
    $update_downloads = $conn->prepare("UPDATE apps SET downloads = downloads + 1 WHERE id = ?");
    $update_downloads->bind_param("i", $app_id);
    $update_downloads->execute();
    $update_downloads->close();
    
    // Redirect to download link
    header("Location: " . $app['drive_link']);
    exit();
}

// Handle review submission
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review']) && isset($_SESSION['user_id'])) {
    $rating = intval($_POST['rating']);
    $comment = trim($_POST['comment']);
    
    if($rating >= 1 && $rating <= 5 && !empty($comment)) {
        $check_review = $conn->prepare("SELECT id FROM reviews WHERE user_id = ? AND app_id = ?");
        $check_review->bind_param("ii", $_SESSION['user_id'], $app_id);
        $check_review->execute();
        
        if($check_review->get_result()->num_rows === 0) {
            $insert_review = $conn->prepare("INSERT INTO reviews (user_id, app_id, rating, comment) VALUES (?, ?, ?, ?)");
            $insert_review->bind_param("iiis", $_SESSION['user_id'], $app_id, $rating, $comment);
            $insert_review->execute();
            $insert_review->close();
        }
        $check_review->close();
    }
    header("Location: app.php?id=" . $app_id);
    exit();
}

// Handle admin actions
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    if(isset($_POST['approve_app'])) {
        $update = $conn->prepare("UPDATE apps SET status = 'approved' WHERE id = ?");
        $update->bind_param("i", $app_id);
        $update->execute();
        $update->close();
        header("Location: app.php?id=" . $app_id);
        exit();
    }
    
    if(isset($_POST['reject_app'])) {
        $update = $conn->prepare("UPDATE apps SET status = 'rejected' WHERE id = ?");
        $update->bind_param("i", $app_id);
        $update->execute();
        $update->close();
        header("Location: app.php?id=" . $app_id);
        exit();
    }
    
    if(isset($_POST['toggle_featured'])) {
        $featured = $app['is_featured'] ? 0 : 1;
        $update = $conn->prepare("UPDATE apps SET is_featured = ? WHERE id = ?");
        $update->bind_param("ii", $featured, $app_id);
        $update->execute();
        $update->close();
        header("Location: app.php?id=" . $app_id);
        exit();
    }
}

// Fetch reviews
$reviews_sql = "SELECT r.*, u.name as user_name 
                FROM reviews r 
                JOIN users u ON r.user_id = u.id 
                WHERE r.app_id = ? 
                ORDER BY r.created_at DESC";
$reviews_stmt = $conn->prepare($reviews_sql);
$reviews_stmt->bind_param("i", $app_id);
$reviews_stmt->execute();
$reviews_result = $reviews_stmt->get_result();

// Parse screenshots
$screenshots = json_decode($app['screenshots'] ?? '[]', true);
if(!is_array($screenshots)) {
    $screenshots = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($app['title']); ?> - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .star-filled { color: #fbbf24; }
        .star-empty { color: #d1d5db; }
        .screenshot-scroll::-webkit-scrollbar { height: 6px; }
        .screenshot-scroll::-webkit-scrollbar-track { background: #f1f1f1; border-radius: 10px; }
        .screenshot-scroll::-webkit-scrollbar-thumb { background: #888; border-radius: 10px; }
        .screenshot-scroll::-webkit-scrollbar-thumb:hover { background: #555; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <a href="index.php" class="text-white font-bold text-xl">Gs Store | Build With Satya</a>
                <a href="category.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                    </svg>
                </a>
            </div>
        </div>
    </header>
    
    <main class="container mx-auto px-4 py-6 pb-24">
        <!-- App Header -->
        <div class="bg-white rounded-2xl shadow-lg p-6 mb-6">
            <div class="flex flex-col md:flex-row md:items-start">
                <!-- App Icon -->
                <div class="md:w-1/4 mb-6 md:mb-0 md:pr-6">
                    <img src="assets/uploads/icons/<?php echo htmlspecialchars($app['icon']); ?>" 
                         alt="<?php echo htmlspecialchars($app['title']); ?>"
                         class="w-32 h-32 mx-auto md:w-48 md:h-48 rounded-3xl object-cover shadow-lg">
                </div>
                
                <!-- App Info -->
                <div class="md:w-3/4">
                    <div class="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                        <div>
                            <h1 class="text-3xl font-bold text-gray-800 mb-2"><?php echo htmlspecialchars($app['title']); ?></h1>
                            <div class="flex items-center space-x-4 text-gray-600 mb-3">
                                <?php if($app['category_name']): ?>
                                <span class="bg-blue-100 text-blue-800 text-sm font-medium px-3 py-1 rounded-full">
                                    <?php echo htmlspecialchars($app['category_name']); ?>
                                </span>
                                <?php endif; ?>
                                <span class="text-sm">Version <?php echo htmlspecialchars($app['version']); ?></span>
                                <span class="text-sm"><?php echo htmlspecialchars($app['size']); ?></span>
                            </div>
                            <p class="text-gray-700 mb-4"><?php echo nl2br(htmlspecialchars($app['description'])); ?></p>
                        </div>
                        
                        <!-- Download Button -->
                        <div class="mt-4 md:mt-0">
                            <form method="POST" class="inline-block">
                                <button type="submit" name="download" 
                                        class="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold py-3 px-8 rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-transform duration-200 flex items-center space-x-2">
                                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                                    </svg>
                                    <span>Download</span>
                                </button>
                            </form>
                            <p class="text-gray-500 text-sm mt-2 text-center md:text-right">
                                <?php echo number_format($app['downloads']); ?> downloads
                            </p>
                        </div>
                    </div>
                    
                    <!-- Publisher Info -->
                    <div class="border-t border-gray-200 pt-4">
                        <div class="flex items-center space-x-4">
                            <div class="bg-purple-100 p-3 rounded-full">
                                <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                </svg>
                            </div>
                            <div>
                                <p class="text-sm text-gray-500">Published by</p>
                                <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($app['publisher_name']); ?></p>
                                <p class="text-sm text-gray-500">on <?php echo date('M d, Y', strtotime($app['created_at'])); ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Admin Controls -->
                    <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <div class="border-t border-gray-200 pt-4 mt-4">
                        <h3 class="font-bold text-gray-800 mb-2">Admin Controls</h3>
                        <div class="flex flex-wrap gap-2">
                            <form method="POST" class="inline">
                                <button type="submit" name="approve_app" 
                                        class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition">
                                    Approve App
                                </button>
                            </form>
                            <form method="POST" class="inline">
                                <button type="submit" name="reject_app" 
                                        class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition">
                                    Reject App
                                </button>
                            </form>
                            <form method="POST" class="inline">
                                <button type="submit" name="toggle_featured" 
                                        class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition">
                                    <?php echo $app['is_featured'] ? 'Remove Featured' : 'Mark as Featured'; ?>
                                </button>
                            </form>
                            <a href="../admin/apps.php" 
                               class="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition inline-block">
                                Manage Apps
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Screenshots -->
        <?php if(!empty($screenshots)): ?>
        <div class="bg-white rounded-2xl shadow-lg p-6 mb-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-4">Screenshots</h2>
            <div class="screenshot-scroll overflow-x-auto pb-4">
                <div class="flex space-x-4">
                    <?php foreach($screenshots as $screenshot): ?>
                    <div class="flex-shrink-0 w-64">
                        <img src="assets/uploads/screenshots/<?php echo htmlspecialchars($screenshot); ?>" 
                             alt="Screenshot"
                             class="w-full h-48 object-cover rounded-xl shadow-md hover:shadow-lg transition-shadow">
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Reviews -->
        <div class="bg-white rounded-2xl shadow-lg p-6 mb-6">
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h2 class="text-2xl font-bold text-gray-800">Reviews</h2>
                    <?php if($app['avg_rating']): ?>
                    <div class="flex items-center mt-2">
                        <div class="flex">
                            <?php
                            $avg_rating = round($app['avg_rating']);
                            for($i = 1; $i <= 5; $i++):
                            ?>
                            <svg class="w-5 h-5 <?php echo $i <= $avg_rating ? 'star-filled' : 'star-empty'; ?>" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                            </svg>
                            <?php endfor; ?>
                        </div>
                        <span class="ml-2 text-gray-600"><?php echo number_format($app['avg_rating'], 1); ?> (<?php echo $app['review_count']; ?> reviews)</span>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Add Review Button (if logged in) -->
                <?php if(isset($_SESSION['user_id'])): ?>
                <button onclick="document.getElementById('reviewModal').classList.remove('hidden')" 
                        class="bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold py-2 px-6 rounded-lg hover:shadow-lg transition">
                    Add Review
                </button>
                <?php endif; ?>
            </div>
            
            <!-- Reviews List -->
            <div class="space-y-6">
                <?php if($reviews_result->num_rows > 0): 
                    while($review = $reviews_result->fetch_assoc()):
                ?>
                <div class="border-b border-gray-100 pb-6 last:border-0">
                    <div class="flex justify-between items-start mb-2">
                        <div class="flex items-center space-x-3">
                            <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                <span class="font-bold text-blue-600"><?php echo strtoupper(substr($review['user_name'], 0, 1)); ?></span>
                            </div>
                            <div>
                                <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($review['user_name']); ?></p>
                                <p class="text-sm text-gray-500"><?php echo date('M d, Y', strtotime($review['created_at'])); ?></p>
                            </div>
                        </div>
                        <div class="flex">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                            <svg class="w-5 h-5 <?php echo $i <= $review['rating'] ? 'star-filled' : 'star-empty'; ?>" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                            </svg>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <p class="text-gray-700"><?php echo nl2br(htmlspecialchars($review['comment'])); ?></p>
                </div>
                <?php endwhile;
                else: ?>
                <div class="text-center py-8">
                    <p class="text-gray-500">No reviews yet. Be the first to review!</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <!-- Review Modal -->
    <?php if(isset($_SESSION['user_id'])): ?>
    <div id="reviewModal" class="fixed inset-0 z-50 bg-black/50 hidden">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-xl font-bold text-gray-800">Write a Review</h3>
                        <button onclick="document.getElementById('reviewModal').classList.add('hidden')" 
                                class="text-gray-400 hover:text-gray-600">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                    
                    <form method="POST">
                        <div class="mb-6">
                            <label class="block text-gray-700 mb-2">Rating</label>
                            <div class="flex space-x-1" id="ratingStars">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                <button type="button" data-rating="<?php echo $i; ?>" 
                                        class="star-rating w-10 h-10 text-2xl hover:scale-110 transition-transform">
                                    ★
                                </button>
                                <?php endfor; ?>
                            </div>
                            <input type="hidden" name="rating" id="selectedRating" value="5" required>
                        </div>
                        
                        <div class="mb-6">
                            <label class="block text-gray-700 mb-2">Your Review</label>
                            <textarea name="comment" rows="4" 
                                      class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                      placeholder="Share your experience with this app..." required></textarea>
                        </div>
                        
                        <div class="flex space-x-3">
                            <button type="button" 
                                    onclick="document.getElementById('reviewModal').classList.add('hidden')" 
                                    class="flex-1 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition">
                                Cancel
                            </button>
                            <button type="submit" name="submit_review" 
                                    class="flex-1 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-lg hover:shadow-lg transition">
                                Submit Review
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Footer Navigation -->
    <footer class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-3 z-40">
        <div class="container mx-auto px-4">
            <div class="flex justify-around">
                <a href="index.php" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
                    <div class="p-2 rounded-full hover:bg-blue-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </div>
                    <span class="text-xs mt-1">Home</span>
                </a>
                
                <a href="category.php" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
                    <div class="p-2 rounded-full hover:bg-blue-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                        </svg>
                    </div>
                    <span class="text-xs mt-1">Categories</span>
                </a>
                
                <a href="profile.php" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
                    <div class="p-2 rounded-full hover:bg-blue-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                    </div>
                    <span class="text-xs mt-1">Profile</span>
                </a>
            </div>
        </div>
    </footer>
    
    <script>
        // Rating stars selection
        const starButtons = document.querySelectorAll('.star-rating');
        const selectedRating = document.getElementById('selectedRating');
        
        starButtons.forEach(star => {
            star.addEventListener('click', function() {
                const rating = parseInt(this.getAttribute('data-rating'));
                selectedRating.value = rating;
                
                starButtons.forEach((s, index) => {
                    if(index < rating) {
                        s.style.color = '#fbbf24';
                    } else {
                        s.style.color = '#d1d5db';
                    }
                });
            });
        });
        
        // Footer button animation
        document.querySelectorAll('footer a').forEach(link => {
            link.addEventListener('click', function(e) {
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 200);
            });
        });
    </script>
</body>
</html>
<?php 
$reviews_stmt->close();
$conn->close();
?>