<?php
require_once '../config.php';

// Check if user is publisher or admin
if(!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'publisher' && $_SESSION['role'] !== 'admin')) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get publisher stats
$stats_sql = "SELECT 
    COUNT(*) as total_apps,
    SUM(downloads) as total_downloads,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_apps
    FROM apps 
    WHERE publisher_id = ?";
    
$stats_stmt = $conn->prepare($stats_sql);
$stats_stmt->bind_param("i", $user_id);
$stats_stmt->execute();
$stats_result = $stats_stmt->get_result();
$stats = $stats_result->fetch_assoc();
$stats_stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Publisher Dashboard - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <a href="../index.php" class="text-white font-bold text-xl">Gs Store</a>
                    <span class="text-white/80">|</span>
                    <span class="text-white font-medium">Publisher Panel</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="../profile.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                    </a>
                    <a href="../logout.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <!-- Sidebar & Main Content -->
    <div class="container mx-auto px-4 py-6">
        <div class="flex flex-col md:flex-row gap-6">
            <!-- Sidebar -->
            <div class="md:w-1/4">
                <div class="bg-white rounded-2xl shadow-lg p-6 mb-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4">Publisher Menu</h3>
                    <nav class="space-y-2">
                        <a href="dashboard.php" 
                           class="flex items-center space-x-3 p-3 rounded-lg bg-blue-50 text-blue-600 font-medium">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                            </svg>
                            <span>Dashboard</span>
                        </a>
                        <a href="upload_app.php" 
                           class="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 text-gray-700 hover:text-blue-600 transition">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                            </svg>
                            <span>Upload App</span>
                        </a>
                        <a href="my_apps.php" 
                           class="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 text-gray-700 hover:text-blue-600 transition">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                            </svg>
                            <span>My Apps</span>
                        </a>
                        <a href="../profile.php" 
                           class="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 text-gray-700 hover:text-blue-600 transition">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                            </svg>
                            <span>My Profile</span>
                        </a>
                    </nav>
                </div>
                
                <!-- Quick Stats -->
                <div class="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl shadow-lg p-6 text-white">
                    <h3 class="font-bold mb-4">Quick Stats</h3>
                    <div class="space-y-4">
                        <div>
                            <p class="text-sm opacity-80">Total Downloads</p>
                            <p class="text-2xl font-bold"><?php echo number_format($stats['total_downloads'] ?? 0); ?></p>
                        </div>
                        <div>
                            <p class="text-sm opacity-80">Pending Apps</p>
                            <p class="text-2xl font-bold"><?php echo $stats['pending_apps'] ?? 0; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="md:w-3/4">
                <!-- Welcome Card -->
                <div class="bg-white rounded-2xl shadow-lg p-6 mb-6">
                    <h1 class="text-2xl font-bold text-gray-800 mb-2">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h1>
                    <p class="text-gray-600">Manage your apps and track performance from your publisher dashboard.</p>
                </div>
                
                <!-- Stats Grid -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <div class="bg-white rounded-2xl shadow-lg p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">Total Apps</p>
                                <p class="text-3xl font-bold text-gray-800"><?php echo $stats['total_apps'] ?? 0; ?></p>
                            </div>
                            <div class="bg-blue-100 p-3 rounded-full">
                                <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                                </svg>
                            </div>
                        </div>
                        <a href="my_apps.php" class="inline-block mt-4 text-blue-600 hover:text-blue-700 text-sm font-medium">
                            View All →
                        </a>
                    </div>
                    
                    <div class="bg-white rounded-2xl shadow-lg p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">Total Downloads</p>
                                <p class="text-3xl font-bold text-gray-800"><?php echo number_format($stats['total_downloads'] ?? 0); ?></p>
                            </div>
                            <div class="bg-green-100 p-3 rounded-full">
                                <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                                </svg>
                            </div>
                        </div>
                        <p class="mt-4 text-sm text-gray-500">All-time downloads</p>
                    </div>
                    
                    <div class="bg-white rounded-2xl shadow-lg p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500">Pending Apps</p>
                                <p class="text-3xl font-bold text-gray-800"><?php echo $stats['pending_apps'] ?? 0; ?></p>
                            </div>
                            <div class="bg-yellow-100 p-3 rounded-full">
                                <svg class="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                        </div>
                        <a href="my_apps.php?filter=pending" class="inline-block mt-4 text-blue-600 hover:text-blue-700 text-sm font-medium">
                            Review →
                        </a>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="bg-white rounded-2xl shadow-lg p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">Quick Actions</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <a href="upload_app.php" 
                           class="group bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-xl shadow hover:shadow-lg transition">
                            <div class="flex items-center space-x-4">
                                <div class="bg-white/20 p-3 rounded-full">
                                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                                    </svg>
                                </div>
                                <div>
                                    <h3 class="text-lg font-bold">Upload New App</h3>
                                    <p class="text-sm opacity-90">Submit your app for review</p>
                                </div>
                            </div>
                        </a>
                        
                        <a href="my_apps.php" 
                           class="group bg-gradient-to-r from-green-500 to-emerald-600 text-white p-6 rounded-xl shadow hover:shadow-lg transition">
                            <div class="flex items-center space-x-4">
                                <div class="bg-white/20 p-3 rounded-full">
                                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                                    </svg>
                                </div>
                                <div>
                                    <h3 class="text-lg font-bold">Manage Apps</h3>
                                    <p class="text-sm opacity-90">View and edit your apps</p>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                
                <!-- Recent Activity -->
                <div class="bg-white rounded-2xl shadow-lg p-6 mt-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">Recent Activity</h2>
                    <?php
                    $activity_sql = "SELECT a.title, a.status, a.created_at 
                                    FROM apps a 
                                    WHERE a.publisher_id = ? 
                                    ORDER BY a.created_at DESC 
                                    LIMIT 5";
                    $activity_stmt = $conn->prepare($activity_sql);
                    $activity_stmt->bind_param("i", $user_id);
                    $activity_stmt->execute();
                    $activity_result = $activity_stmt->get_result();
                    
                    if($activity_result->num_rows > 0):
                    ?>
                    <div class="space-y-4">
                        <?php while($activity = $activity_result->fetch_assoc()): 
                            $status_color = $activity['status'] === 'approved' ? 'bg-green-100 text-green-800' : 
                                          ($activity['status'] === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                          'bg-red-100 text-red-800');
                        ?>
                        <div class="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50">
                            <div>
                                <h4 class="font-medium text-gray-800"><?php echo htmlspecialchars($activity['title']); ?></h4>
                                <p class="text-sm text-gray-500"><?php echo date('M d, Y', strtotime($activity['created_at'])); ?></p>
                            </div>
                            <span class="px-3 py-1 rounded-full text-xs font-medium <?php echo $status_color; ?>">
                                <?php echo ucfirst($activity['status']); ?>
                            </span>
                        </div>
                        <?php endwhile; ?>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-8">
                        <p class="text-gray-500">No recent activity</p>
                        <a href="upload_app.php" class="inline-block mt-2 text-blue-600 hover:text-blue-700">
                            Upload your first app →
                        </a>
                    </div>
                    <?php endif; 
                    $activity_stmt->close();
                    ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Back to Store -->
    <div class="container mx-auto px-4 py-6">
        <a href="../index.php" class="inline-flex items-center text-gray-600 hover:text-gray-800">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
            </svg>
            Back to Store
        </a>
    </div>
</body>
</html>
<?php $conn->close(); ?>