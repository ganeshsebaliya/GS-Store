<?php
require_once '../config.php';

// Check if user is publisher or admin
if(!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'publisher' && $_SESSION['role'] !== 'admin')) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$app_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if($app_id === 0) {
    header("Location: my_apps.php");
    exit();
}

// Verify app belongs to user
$verify_sql = "SELECT * FROM apps WHERE id = ? AND publisher_id = ?";
$verify_stmt = $conn->prepare($verify_sql);
$verify_stmt->bind_param("ii", $app_id, $user_id);
$verify_stmt->execute();
$verify_result = $verify_stmt->get_result();

if($verify_result->num_rows === 0) {
    header("Location: my_apps.php");
    exit();
}

$app = $verify_result->fetch_assoc();
$verify_stmt->close();

// Fetch categories
$cats_sql = "SELECT id, name FROM categories ORDER BY name";
$cats_stmt = $conn->prepare($cats_sql);
$cats_stmt->execute();
$cats_result = $cats_stmt->get_result();

// Parse screenshots
$screenshots = json_decode($app['screenshots'] ?? '[]', true);
if(!is_array($screenshots)) {
    $screenshots = [];
}

$message = '';
$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $version = trim($_POST['version']);
    $size = trim($_POST['size']);
    $category_id = intval($_POST['category_id']);
    $description = trim($_POST['description']);
    $drive_link = trim($_POST['drive_link']);
    
    // Validate inputs
    if(empty($title) || empty($version) || empty($size) || empty($category_id) || empty($description) || empty($drive_link)) {
        $error = "Please fill in all required fields";
    } else {
        // Convert Drive link
        require_once '../config.php';
        function convertDriveLinkEdit($link) {
            if(strpos($link, 'uc?export=download') !== false) {
                return $link;
            }
            
            $patterns = [
                '/\/d\/([a-zA-Z0-9_-]+)/',
                '/id=([a-zA-Z0-9_-]+)/',
                '/\/file\/d\/([a-zA-Z0-9_-]+)/',
            ];
            
            foreach($patterns as $pattern) {
                if(preg_match($pattern, $link, $matches)) {
                    $file_id = $matches[1];
                    return "https://drive.google.com/uc?export=download&id=" . $file_id;
                }
            }
            
            return false;
        }
        
        $direct_link = convertDriveLinkEdit($drive_link);
        if(!$direct_link) {
            $error = "Invalid Google Drive link. Please provide a valid share link.";
        } else {
            // Handle icon update
            $icon_name = $app['icon'];
            if(isset($_FILES['icon']) && $_FILES['icon']['error'] === 0) {
                function uploadFileEdit($file, $target_dir) {
                    $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
                    $max_size = 3 * 1024 * 1024;
                    
                    if($file['error'] !== 0 || !in_array($file['type'], $allowed_types) || $file['size'] > $max_size) {
                        return false;
                    }
                    
                    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
                    $filename = uniqid() . '_' . time() . '.' . $extension;
                    $target_file = $target_dir . $filename;
                    
                    if(move_uploaded_file($file['tmp_name'], $target_file)) {
                        return $filename;
                    }
                    
                    return false;
                }
                
                $new_icon = uploadFileEdit($_FILES['icon'], '../assets/uploads/icons/');
                if($new_icon) {
                    // Delete old icon
                    $old_icon_path = "../assets/uploads/icons/" . $icon_name;
                    if(file_exists($old_icon_path)) {
                        unlink($old_icon_path);
                    }
                    $icon_name = $new_icon;
                }
            }
            
            // Handle screenshots update
            $screenshots_array = $screenshots;
            if(isset($_FILES['screenshots']) && is_array($_FILES['screenshots']['name'])) {
                for($i = 0; $i < count($_FILES['screenshots']['name']); $i++) {
                    if($_FILES['screenshots']['error'][$i] === 0) {
                        $screenshot = [
                            'name' => $_FILES['screenshots']['name'][$i],
                            'type' => $_FILES['screenshots']['type'][$i],
                            'tmp_name' => $_FILES['screenshots']['tmp_name'][$i],
                            'error' => $_FILES['screenshots']['error'][$i],
                            'size' => $_FILES['screenshots']['size'][$i]
                        ];
                        
                        $screenshot_name = uploadFileEdit($screenshot, '../assets/uploads/screenshots/');
                        if($screenshot_name) {
                            $screenshots_array[] = $screenshot_name;
                        }
                    }
                }
            }
            
            // Handle screenshot removal
            if(isset($_POST['remove_screenshots']) && is_array($_POST['remove_screenshots'])) {
                foreach($_POST['remove_screenshots'] as $screenshot_to_remove) {
                    $screenshot_path = "../assets/uploads/screenshots/" . $screenshot_to_remove;
                    if(file_exists($screenshot_path)) {
                        unlink($screenshot_path);
                    }
                    $key = array_search($screenshot_to_remove, $screenshots_array);
                    if($key !== false) {
                        unset($screenshots_array[$key]);
                    }
                }
                $screenshots_array = array_values($screenshots_array);
            }
            
            $screenshots_json = json_encode($screenshots_array);
            
            // Update app
            $update_sql = "UPDATE apps SET title = ?, icon = ?, screenshots = ?, category_id = ?, 
                          version = ?, size = ?, description = ?, drive_link = ?, status = 'pending' 
                          WHERE id = ? AND publisher_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("sssissssiii", $title, $icon_name, $screenshots_json, $category_id, 
                                    $version, $size, $description, $direct_link, $app_id, $user_id);
            
            if($update_stmt->execute()) {
                $success = "App updated successfully! It has been sent for review again.";
                // Refresh app data
                $app['title'] = $title;
                $app['version'] = $version;
                $app['size'] = $size;
                $app['category_id'] = $category_id;
                $app['description'] = $description;
                $app['drive_link'] = $direct_link;
                $app['icon'] = $icon_name;
                $screenshots = $screenshots_array;
            } else {
                $error = "Failed to update app. Please try again.";
            }
            $update_stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit App - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .current-image { transition: all 0.2s; }
        .current-image:hover { transform: scale(1.05); }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <a href="../index.php" class="text-white font-bold text-xl">Gs Store</a>
                    <span class="text-white/80">|</span>
                    <span class="text-white font-medium">Edit App</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </a>
                    <a href="../logout.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            <!-- Breadcrumb -->
            <div class="mb-6">
                <nav class="flex space-x-2 text-sm text-gray-600">
                    <a href="../index.php" class="hover:text-blue-600">Home</a>
                    <span>/</span>
                    <a href="dashboard.php" class="hover:text-blue-600">Publisher</a>
                    <span>/</span>
                    <a href="my_apps.php" class="hover:text-blue-600">My Apps</a>
                    <span>/</span>
                    <span class="text-gray-800 font-medium">Edit App</span>
                </nav>
            </div>
            
            <!-- Form Card -->
            <div class="bg-white rounded-2xl shadow-xl p-6">
                <h1 class="text-2xl font-bold text-gray-800 mb-2">Edit App</h1>
                <p class="text-gray-600 mb-6">Update your app information</p>
                
                <?php if($error): ?>
                <div class="mb-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl">
                    <?php echo htmlspecialchars($error); ?>
                </div>
                <?php endif; ?>
                
                <?php if($success): ?>
                <div class="mb-6 p-4 bg-green-50 border border-green-200 text-green-700 rounded-xl">
                    <?php echo htmlspecialchars($success); ?>
                </div>
                <?php endif; ?>
                
                <form method="POST" action="" enctype="multipart/form-data" id="editForm">
                    <!-- Basic Info -->
                    <div class="mb-8">
                        <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b">Basic Information</h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">App Name *</label>
                                <input type="text" name="title" required value="<?php echo htmlspecialchars($app['title']); ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>
                            
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">Version *</label>
                                <input type="text" name="version" required value="<?php echo htmlspecialchars($app['version']); ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>
                            
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">Size *</label>
                                <input type="text" name="size" required value="<?php echo htmlspecialchars($app['size']); ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>
                            
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">Category *</label>
                                <select name="category_id" required
                                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="">Select Category</option>
                                    <?php 
                                    $cats_result->data_seek(0);
                                    while($cat = $cats_result->fetch_assoc()): 
                                    ?>
                                    <option value="<?php echo $cat['id']; ?>" <?php echo $app['category_id'] == $cat['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cat['name']); ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mt-6">
                            <label class="block text-gray-700 text-sm font-medium mb-2">Description *</label>
                            <textarea name="description" required rows="4"
                                      class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"><?php echo htmlspecialchars($app['description']); ?></textarea>
                        </div>
                    </div>
                    
                    <!-- Current Files -->
                    <div class="mb-8">
                        <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b">Current Files</h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Current Icon -->
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">Current Icon</label>
                                <div class="border border-gray-200 rounded-xl p-4">
                                    <img src="../assets/uploads/icons/<?php echo htmlspecialchars($app['icon']); ?>" 
                                         alt="Current Icon"
                                         class="w-24 h-24 mx-auto rounded-xl object-cover border">
                                    <p class="text-center text-sm text-gray-500 mt-2">Current app icon</p>
                                </div>
                            </div>
                            
                            <!-- Current Screenshots -->
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">Current Screenshots</label>
                                <?php if(!empty($screenshots)): ?>
                                <div class="border border-gray-200 rounded-xl p-4">
                                    <div class="flex flex-wrap gap-2">
                                        <?php foreach($screenshots as $screenshot): ?>
                                        <div class="relative">
                                            <img src="../assets/uploads/screenshots/<?php echo htmlspecialchars($screenshot); ?>" 
                                                 alt="Screenshot"
                                                 class="current-image w-20 h-36 object-cover rounded-lg border">
                                            <label class="absolute top-1 right-1">
                                                <input type="checkbox" name="remove_screenshots[]" value="<?php echo htmlspecialchars($screenshot); ?>"
                                                       class="hidden peer">
                                                <div class="w-5 h-5 bg-white rounded-full shadow flex items-center justify-center peer-checked:bg-red-500 cursor-pointer">
                                                    <svg class="w-3 h-3 text-gray-400 peer-checked:text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                                                    </svg>
                                                </div>
                                            </label>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <p class="text-center text-sm text-gray-500 mt-2">Check to remove screenshots</p>
                                </div>
                                <?php else: ?>
                                <div class="border border-dashed border-gray-300 rounded-xl p-8 text-center">
                                    <p class="text-gray-500">No screenshots uploaded yet</p>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Update Files -->
                    <div class="mb-8">
                        <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b">Update Files (Optional)</h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- New Icon -->
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">New Icon</label>
                                <div class="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-blue-400 transition">
                                    <input type="file" name="icon" accept="image/png, image/jpeg" 
                                           class="hidden" id="iconInput" onchange="previewIcon(event)">
                                    <label for="iconInput" class="cursor-pointer">
                                        <div class="mx-auto w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center mb-3">
                                            <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                            </svg>
                                        </div>
                                        <p class="text-sm text-gray-600">Click to upload new icon</p>
                                        <p class="text-xs text-gray-500 mt-1">Leave empty to keep current</p>
                                    </label>
                                </div>
                                <div id="iconPreview" class="mt-4 hidden">
                                    <p class="text-sm text-gray-600 mb-2">New icon preview:</p>
                                    <img id="iconPreviewImg" class="w-20 h-20 rounded-xl object-cover border">
                                </div>
                            </div>
                            
                            <!-- New Screenshots -->
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">Add More Screenshots</label>
                                <div class="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-blue-400 transition">
                                    <input type="file" name="screenshots[]" accept="image/png, image/jpeg" multiple
                                           class="hidden" id="screenshotsInput" onchange="previewScreenshots(event)">
                                    <label for="screenshotsInput" class="cursor-pointer">
                                        <div class="mx-auto w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center mb-3">
                                            <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path>
                                            </svg>
                                        </div>
                                        <p class="text-sm text-gray-600">Click to add more screenshots</p>
                                        <p class="text-xs text-gray-500 mt-1">Multiple PNG/JPG files, max 3MB each</p>
                                    </label>
                                </div>
                                <div id="screenshotsPreview" class="mt-4 hidden">
                                    <p class="text-sm text-gray-600 mb-2">New screenshots:</p>
                                    <div id="screenshotsList" class="flex flex-wrap gap-2"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Drive Link -->
                    <div class="mb-8">
                        <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b">Download Link</h2>
                        
                        <div>
                            <label class="block text-gray-700 text-sm font-medium mb-2">Google Drive Link *</label>
                            <input type="url" name="drive_link" required value="<?php echo htmlspecialchars($app['drive_link']); ?>"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   placeholder="https://drive.google.com/uc?export=download&id=FILE_ID"
                                   onblur="convertDriveLink(this)">
                            <p class="text-sm text-gray-500 mt-2">
                                <a href="javascript:void(0)" onclick="showDriveHelp()" class="text-blue-600 hover:text-blue-700">
                                    Need help with Drive link?
                                </a>
                            </p>
                        </div>
                    </div>
                    
                    <!-- Submit -->
                    <div class="flex justify-between items-center pt-6 border-t">
                        <a href="my_apps.php" class="text-gray-600 hover:text-gray-800 font-medium">
                            ← Back to My Apps
                        </a>
                        <div class="space-x-3">
                            <a href="../app.php?id=<?php echo $app_id; ?>" 
                               class="inline-block px-6 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition">
                                View App
                            </a>
                            <button type="submit" 
                                    class="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold py-3 px-8 rounded-xl hover:shadow-lg transition-transform active:scale-95">
                                Update App
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Note -->
            <div class="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-xl">
                <div class="flex items-start space-x-3">
                    <svg class="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <div>
                        <h4 class="font-medium text-blue-800">Important Note</h4>
                        <p class="text-sm text-blue-700 mt-1">
                            When you update your app, it will be sent for review again. The app status will change to "pending" 
                            until our admin team approves the changes.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Preview new icon
        function previewIcon(event) {
            const input = event.target;
            const preview = document.getElementById('iconPreview');
            const img = document.getElementById('iconPreviewImg');
            
            if(input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    img.src = e.target.result;
                    preview.classList.remove('hidden');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        // Preview new screenshots
        function previewScreenshots(event) {
            const input = event.target;
            const preview = document.getElementById('screenshotsPreview');
            const list = document.getElementById('screenshotsList');
            
            list.innerHTML = '';
            
            if(input.files && input.files.length > 0) {
                preview.classList.remove('hidden');
                
                for(let i = 0; i < Math.min(input.files.length, 5); i++) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const div = document.createElement('div');
                        div.className = 'current-image';
                        div.innerHTML = `
                            <img src="${e.target.result}" class="w-20 h-36 object-cover rounded-lg border">
                            <p class="text-xs text-gray-500 truncate mt-1">${input.files[i].name}</p>
                        `;
                        list.appendChild(div);
                    }
                    reader.readAsDataURL(input.files[i]);
                }
            }
        }
        
        // Convert Drive link
        function convertDriveLink(input) {
            let link = input.value.trim();
            if(!link) return;
            
            let fileId = '';
            let match = link.match(/\/d\/([a-zA-Z0-9_-]+)/);
            if(match) fileId = match[1];
            
            if(!fileId) {
                match = link.match(/id=([a-zA-Z0-9_-]+)/);
                if(match) fileId = match[1];
            }
            
            if(!fileId) {
                match = link.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
                if(match) fileId = match[1];
            }
            
            if(fileId && !link.includes('uc?export=download')) {
                input.value = `https://drive.google.com/uc?export=download&id=${fileId}`;
                showMessage('Link converted to direct download format', 'success');
            }
        }
        
        // Show Drive help
        function showDriveHelp() {
            alert('For Google Drive links:\n\n1. Share your file and copy the share link\n2. We accept formats like: https://drive.google.com/file/d/FILE_ID/view\n3. The system will convert it to a direct download link\n\nMake sure the file is shared with "Anyone with the link" permission.');
        }
        
        // Show message
        function showMessage(text, type) {
            const div = document.createElement('div');
            div.className = `fixed top-4 right-4 p-4 rounded-xl shadow-lg z-50 ${type === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 'bg-yellow-100 text-yellow-800 border border-yellow-200'}`;
            div.innerHTML = `
                <div class="flex items-center space-x-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span>${text}</span>
                </div>
            `;
            document.body.appendChild(div);
            
            setTimeout(() => {
                div.remove();
            }, 3000);
        }
    </script>
</body>
</html>
<?php 
$cats_stmt->close();
$conn->close();
?>