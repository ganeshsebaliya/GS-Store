<?php
require_once '../config.php';

// Check if user is publisher or admin
if(!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'publisher' && $_SESSION['role'] !== 'admin')) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle app deletion
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_app'])) {
    $app_id = intval($_POST['app_id']);
    
    // Verify app belongs to user
    $verify_sql = "SELECT icon, screenshots FROM apps WHERE id = ? AND publisher_id = ?";
    $verify_stmt = $conn->prepare($verify_sql);
    $verify_stmt->bind_param("ii", $app_id, $user_id);
    $verify_stmt->execute();
    $verify_result = $verify_stmt->get_result();
    
    if($verify_result->num_rows === 1) {
        $app = $verify_result->fetch_assoc();
        
        // Delete icon file
        if($app['icon']) {
            $icon_path = "../assets/uploads/icons/" . $app['icon'];
            if(file_exists($icon_path)) {
                unlink($icon_path);
            }
        }
        
        // Delete screenshots files
        $screenshots = json_decode($app['screenshots'], true);
        if(is_array($screenshots)) {
            foreach($screenshots as $screenshot) {
                $screenshot_path = "../assets/uploads/screenshots/" . $screenshot;
                if(file_exists($screenshot_path)) {
                    unlink($screenshot_path);
                }
            }
        }
        
        // Delete from database
        $delete_sql = "DELETE FROM apps WHERE id = ?";
        $delete_stmt = $conn->prepare($delete_sql);
        $delete_stmt->bind_param("i", $app_id);
        $delete_stmt->execute();
        $delete_stmt->close();
        
        $message = "App deleted successfully";
    }
    $verify_stmt->close();
}

// Filter by status
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$status_filter = '';

switch($filter) {
    case 'pending':
        $status_filter = "AND a.status = 'pending'";
        break;
    case 'approved':
        $status_filter = "AND a.status = 'approved'";
        break;
    case 'rejected':
        $status_filter = "AND a.status = 'rejected'";
        break;
}

// Fetch apps
$apps_sql = "SELECT a.id, a.title, a.icon, a.status, a.downloads, a.created_at, c.name as category_name 
            FROM apps a 
            LEFT JOIN categories c ON a.category_id = c.id 
            WHERE a.publisher_id = ? $status_filter 
            ORDER BY a.created_at DESC";
$apps_stmt = $conn->prepare($apps_sql);
$apps_stmt->bind_param("i", $user_id);
$apps_stmt->execute();
$apps_result = $apps_stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Apps - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <a href="../index.php" class="text-white font-bold text-xl">Gs Store</a>
                    <span class="text-white/80">|</span>
                    <span class="text-white font-medium">My Apps</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </a>
                    <a href="../logout.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-6xl mx-auto">
            <!-- Breadcrumb -->
            <div class="mb-6">
                <nav class="flex space-x-2 text-sm text-gray-600">
                    <a href="../index.php" class="hover:text-blue-600">Home</a>
                    <span>/</span>
                    <a href="dashboard.php" class="hover:text-blue-600">Publisher</a>
                    <span>/</span>
                    <span class="text-gray-800 font-medium">My Apps</span>
                </nav>
            </div>
            
            <!-- Header -->
            <div class="flex flex-col md:flex-row md:items-center justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">My Apps</h1>
                    <p class="text-gray-600">Manage your uploaded applications</p>
                </div>
                <a href="upload_app.php" 
                   class="mt-4 md:mt-0 inline-flex items-center bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold py-2 px-6 rounded-xl hover:shadow-lg transition">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                    </svg>
                    Upload New App
                </a>
            </div>
            
            <!-- Filters -->
            <div class="bg-white rounded-xl shadow-lg p-4 mb-6">
                <div class="flex flex-wrap gap-2">
                    <a href="?filter=all" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $filter === 'all' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        All Apps
                    </a>
                    <a href="?filter=pending" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $filter === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Pending
                    </a>
                    <a href="?filter=approved" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $filter === 'approved' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Approved
                    </a>
                    <a href="?filter=rejected" 
                       class="px-4 py-2 rounded-full text-sm font-medium <?php echo $filter === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'; ?>">
                        Rejected
                    </a>
                </div>
            </div>
            
            <!-- Apps Table -->
            <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                <?php if($apps_result->num_rows > 0): ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">App</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Downloads</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                                <th class="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php while($app = $apps_result->fetch_assoc()): 
                                $status_color = $app['status'] === 'approved' ? 'bg-green-100 text-green-800' : 
                                              ($app['status'] === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                              'bg-red-100 text-red-800');
                            ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4">
                                    <div class="flex items-center space-x-3">
                                        <img src="../assets/uploads/icons/<?php echo htmlspecialchars($app['icon']); ?>" 
                                             alt="<?php echo htmlspecialchars($app['title']); ?>"
                                             class="w-10 h-10 rounded-lg object-cover">
                                        <div>
                                            <h4 class="font-medium text-gray-800"><?php echo htmlspecialchars($app['title']); ?></h4>
                                            <a href="../app.php?id=<?php echo $app['id']; ?>" 
                                               class="text-sm text-blue-600 hover:text-blue-700">View</a>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-700"><?php echo htmlspecialchars($app['category_name']); ?></td>
                                <td class="px-6 py-4">
                                    <span class="px-3 py-1 rounded-full text-xs font-medium <?php echo $status_color; ?>">
                                        <?php echo ucfirst($app['status']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-700"><?php echo number_format($app['downloads']); ?></td>
                                <td class="px-6 py-4 text-sm text-gray-700"><?php echo date('M d, Y', strtotime($app['created_at'])); ?></td>
                                <td class="px-6 py-4">
                                    <div class="flex items-center space-x-2">
                                        <a href="edit_app.php?id=<?php echo $app['id']; ?>" 
                                           class="text-blue-600 hover:text-blue-700 p-1 hover:bg-blue-50 rounded">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                            </svg>
                                        </a>
                                        <form method="POST" onsubmit="return confirm('Are you sure you want to delete this app? This action cannot be undone.');">
                                            <input type="hidden" name="app_id" value="<?php echo $app['id']; ?>">
                                            <button type="submit" name="delete_app" 
                                                    class="text-red-600 hover:text-red-700 p-1 hover:bg-red-50 rounded">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                </svg>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-12">
                    <div class="text-gray-400 mb-4">
                        <svg class="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-600 mb-2">No apps found</h3>
                    <p class="text-gray-500 mb-6">You haven't uploaded any apps yet</p>
                    <a href="upload_app.php" 
                       class="inline-flex items-center bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold py-2 px-6 rounded-xl hover:shadow-lg transition">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                        </svg>
                        Upload Your First App
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Back to Dashboard -->
    <div class="container mx-auto px-4 py-6">
        <a href="dashboard.php" class="inline-flex items-center text-gray-600 hover:text-gray-800">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
            </svg>
            Back to Dashboard
        </a>
    </div>
    
    <script>
        // Show message if app was deleted
        <?php if(isset($message)): ?>
        alert("<?php echo $message; ?>");
        location.reload();
        <?php endif; ?>
    </script>
</body>
</html>
<?php 
$apps_stmt->close();
$conn->close();
?>