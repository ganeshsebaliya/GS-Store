<?php
require_once '../config.php';

// Check if user is publisher or admin
if(!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'publisher' && $_SESSION['role'] !== 'admin')) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';
$success = '';

// Fetch categories for dropdown
$cats_sql = "SELECT id, name FROM categories ORDER BY name";
$cats_stmt = $conn->prepare($cats_sql);
$cats_stmt->execute();
$cats_result = $cats_stmt->get_result();

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $version = trim($_POST['version']);
    $size = trim($_POST['size']);
    $category_id = intval($_POST['category_id']);
    $description = trim($_POST['description']);
    $drive_link = trim($_POST['drive_link']);
    
    // Validate inputs
    if(empty($title) || empty($version) || empty($size) || empty($category_id) || empty($description) || empty($drive_link)) {
        $error = "Please fill in all required fields";
    } elseif(!isset($_FILES['icon']) || $_FILES['icon']['error'] === 4) {
        $error = "App icon is required";
    } else {
        // Validate and process Drive link
        $direct_link = convertDriveLink($drive_link);
        if(!$direct_link) {
            $error = "Invalid Google Drive link. Please provide a valid share link.";
        } else {
            // Handle icon upload
            $icon = $_FILES['icon'];
            $icon_name = uploadFile($icon, '../assets/uploads/icons/');
            
            if(!$icon_name) {
                $error = "Invalid icon file. Please upload PNG or JPG image (max 3MB)";
            } else {
                // Handle screenshots upload
                $screenshots = [];
                if(isset($_FILES['screenshots']) && is_array($_FILES['screenshots']['name'])) {
                    for($i = 0; $i < count($_FILES['screenshots']['name']); $i++) {
                        if($_FILES['screenshots']['error'][$i] === 0) {
                            $screenshot = [
                                'name' => $_FILES['screenshots']['name'][$i],
                                'type' => $_FILES['screenshots']['type'][$i],
                                'tmp_name' => $_FILES['screenshots']['tmp_name'][$i],
                                'error' => $_FILES['screenshots']['error'][$i],
                                'size' => $_FILES['screenshots']['size'][$i]
                            ];
                            
                            $screenshot_name = uploadFile($screenshot, '../assets/uploads/screenshots/');
                            if($screenshot_name) {
                                $screenshots[] = $screenshot_name;
                            }
                        }
                    }
                }
                
                // Insert into database
                $screenshots_json = json_encode($screenshots);
                
                $insert_sql = "INSERT INTO apps (title, icon, screenshots, category_id, version, size, description, publisher_id, drive_link, status) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')";
                $insert_stmt = $conn->prepare($insert_sql);
                $insert_stmt->bind_param("sssisssis", $title, $icon_name, $screenshots_json, $category_id, $version, $size, $description, $user_id, $direct_link);
                
                if($insert_stmt->execute()) {
                    $success = "App uploaded successfully! It will be reviewed by our team.";
                    // Clear form
                    $title = $version = $size = $description = $drive_link = '';
                } else {
                    $error = "Failed to upload app. Please try again.";
                }
                $insert_stmt->close();
            }
        }
    }
}

function convertDriveLink($link) {
    // If already direct link, return as is
    if(strpos($link, 'uc?export=download') !== false) {
        return $link;
    }
    
    // Extract file ID from various Google Drive URL formats
    $patterns = [
        '/\/d\/([a-zA-Z0-9_-]+)/',
        '/id=([a-zA-Z0-9_-]+)/',
        '/\/file\/d\/([a-zA-Z0-9_-]+)/',
    ];
    
    foreach($patterns as $pattern) {
        if(preg_match($pattern, $link, $matches)) {
            $file_id = $matches[1];
            return "https://drive.google.com/uc?export=download&id=" . $file_id;
        }
    }
    
    return false;
}

function uploadFile($file, $target_dir) {
    // Check file error
    if($file['error'] !== 0) {
        return false;
    }
    
    // Check file type
    $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
    if(!in_array($file['type'], $allowed_types)) {
        return false;
    }
    
    // Check file size (3MB max)
    $max_size = 3 * 1024 * 1024;
    if($file['size'] > $max_size) {
        return false;
    }
    
    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '_' . time() . '.' . $extension;
    $target_file = $target_dir . $filename;
    
    // Move uploaded file
    if(move_uploaded_file($file['tmp_name'], $target_file)) {
        return $filename;
    }
    
    return false;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload App - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .file-input:focus + label { box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); }
        .preview-image { transition: transform 0.2s; }
        .preview-image:hover { transform: scale(1.05); }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <a href="../index.php" class="text-white font-bold text-xl">Gs Store</a>
                    <span class="text-white/80">|</span>
                    <span class="text-white font-medium">Upload App</span>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </a>
                    <a href="../logout.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <div class="container mx-auto px-4 py-6">
        <div class="max-w-4xl mx-auto">
            <!-- Breadcrumb -->
            <div class="mb-6">
                <nav class="flex space-x-2 text-sm text-gray-600">
                    <a href="../index.php" class="hover:text-blue-600">Home</a>
                    <span>/</span>
                    <a href="dashboard.php" class="hover:text-blue-600">Publisher</a>
                    <span>/</span>
                    <span class="text-gray-800 font-medium">Upload App</span>
                </nav>
            </div>
            
            <!-- Form Card -->
            <div class="bg-white rounded-2xl shadow-xl p-6">
                <h1 class="text-2xl font-bold text-gray-800 mb-2">Upload New App</h1>
                <p class="text-gray-600 mb-6">Fill in the details below to submit your app for review</p>
                
                <?php if($error): ?>
                <div class="mb-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-xl">
                    <?php echo htmlspecialchars($error); ?>
                </div>
                <?php endif; ?>
                
                <?php if($success): ?>
                <div class="mb-6 p-4 bg-green-50 border border-green-200 text-green-700 rounded-xl">
                    <?php echo htmlspecialchars($success); ?>
                </div>
                <?php endif; ?>
                
                <form method="POST" action="" enctype="multipart/form-data" id="uploadForm">
                    <!-- Basic Info -->
                    <div class="mb-8">
                        <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b">Basic Information</h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">App Name *</label>
                                <input type="text" name="title" required value="<?php echo isset($title) ? htmlspecialchars($title) : ''; ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                       placeholder="My Awesome App">
                            </div>
                            
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">Version *</label>
                                <input type="text" name="version" required value="<?php echo isset($version) ? htmlspecialchars($version) : ''; ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                       placeholder="1.0.0">
                            </div>
                            
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">Size *</label>
                                <input type="text" name="size" required value="<?php echo isset($size) ? htmlspecialchars($size) : ''; ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                       placeholder="25 MB">
                            </div>
                            
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">Category *</label>
                                <select name="category_id" required
                                        class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="">Select Category</option>
                                    <?php while($cat = $cats_result->fetch_assoc()): ?>
                                    <option value="<?php echo $cat['id']; ?>" <?php echo (isset($category_id) && $category_id == $cat['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cat['name']); ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mt-6">
                            <label class="block text-gray-700 text-sm font-medium mb-2">Description *</label>
                            <textarea name="description" required rows="4"
                                      class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                      placeholder="Describe your app features, functionality, and requirements..."><?php echo isset($description) ? htmlspecialchars($description) : ''; ?></textarea>
                        </div>
                    </div>
                    
                    <!-- Files Upload -->
                    <div class="mb-8">
                        <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b">Media Files</h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- App Icon -->
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">App Icon *</label>
                                <div class="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-blue-400 transition">
                                    <input type="file" name="icon" accept="image/png, image/jpeg" required 
                                           class="hidden file-input" id="iconInput" onchange="previewIcon(event)">
                                    <label for="iconInput" class="cursor-pointer">
                                        <div class="mx-auto w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center mb-3">
                                            <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                            </svg>
                                        </div>
                                        <p class="text-sm text-gray-600">Click to upload icon</p>
                                        <p class="text-xs text-gray-500 mt-1">PNG or JPG, max 3MB</p>
                                    </label>
                                </div>
                                <div id="iconPreview" class="mt-4 hidden">
                                    <p class="text-sm text-gray-600 mb-2">Preview:</p>
                                    <img id="iconPreviewImg" class="w-20 h-20 rounded-xl object-cover border">
                                </div>
                            </div>
                            
                            <!-- Screenshots -->
                            <div>
                                <label class="block text-gray-700 text-sm font-medium mb-2">Screenshots</label>
                                <div class="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center hover:border-blue-400 transition">
                                    <input type="file" name="screenshots[]" accept="image/png, image/jpeg" multiple
                                           class="hidden file-input" id="screenshotsInput" onchange="previewScreenshots(event)">
                                    <label for="screenshotsInput" class="cursor-pointer">
                                        <div class="mx-auto w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center mb-3">
                                            <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path>
                                            </svg>
                                        </div>
                                        <p class="text-sm text-gray-600">Click to upload screenshots</p>
                                        <p class="text-xs text-gray-500 mt-1">Multiple PNG/JPG files, max 3MB each</p>
                                    </label>
                                </div>
                                <div id="screenshotsPreview" class="mt-4 hidden">
                                    <p class="text-sm text-gray-600 mb-2">Preview:</p>
                                    <div id="screenshotsList" class="flex flex-wrap gap-2"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Drive Link -->
                    <div class="mb-8">
                        <h2 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b">Download Link</h2>
                        
                        <div>
                            <label class="block text-gray-700 text-sm font-medium mb-2">Google Drive Link *</label>
                            <input type="url" name="drive_link" required value="<?php echo isset($drive_link) ? htmlspecialchars($drive_link) : ''; ?>"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   placeholder="https://drive.google.com/file/d/FILE_ID/view?usp=sharing"
                                   onblur="convertDriveLink(this)">
                            <p class="text-sm text-gray-500 mt-2">
                                <a href="javascript:void(0)" onclick="showDriveHelp()" class="text-blue-600 hover:text-blue-700">
                                    Need help with Drive link? Click here
                                </a>
                            </p>
                            <div id="driveHelp" class="hidden mt-4 p-4 bg-blue-50 border border-blue-200 rounded-xl">
                                <h4 class="font-medium text-blue-800 mb-2">Google Drive Link Instructions:</h4>
                                <ul class="text-sm text-blue-700 space-y-1 list-disc ml-5">
                                    <li>Share your file on Google Drive and copy the share link</li>
                                    <li>We accept formats like: <code class="text-xs">https://drive.google.com/file/d/FILE_ID/view</code></li>
                                    <li>Or: <code class="text-xs">https://drive.google.com/open?id=FILE_ID</code></li>
                                    <li>The system will automatically convert it to a direct download link</li>
                                </ul>
                                <p class="text-sm text-blue-700 mt-2">
                                    <strong>Note:</strong> Make sure the file is shared with "Anyone with the link" permission.
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Submit -->
                    <div class="flex justify-between items-center pt-6 border-t">
                        <a href="dashboard.php" class="text-gray-600 hover:text-gray-800 font-medium">
                            ← Back to Dashboard
                        </a>
                        <button type="submit" 
                                class="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold py-3 px-8 rounded-xl hover:shadow-lg transition-transform active:scale-95">
                            Submit for Review
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- Note -->
            <div class="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-xl">
                <div class="flex items-start space-x-3">
                    <svg class="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <div>
                        <h4 class="font-medium text-yellow-800">Submission Process</h4>
                        <p class="text-sm text-yellow-700 mt-1">
                            After submission, your app will be reviewed by our admin team. You'll be notified when it's approved.
                            This usually takes 24-48 hours.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Drive Link Generator Modal -->
    <div id="driveModal" class="fixed inset-0 z-50 bg-black/50 hidden">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-2xl shadow-2xl w-full max-w-2xl">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-xl font-bold text-gray-800">Google Drive Direct Link Generator</h3>
                        <button onclick="document.getElementById('driveModal').classList.add('hidden')" 
                                class="text-gray-400 hover:text-gray-600">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                    
                    <div class="space-y-4">
                        <div class="p-4 bg-blue-50 rounded-xl">
                            <h4 class="font-medium text-blue-800 mb-2">Quick Guide:</h4>
                            <ol class="text-sm text-blue-700 space-y-2 list-decimal ml-5">
                                <li>Upload your APK file to Google Drive</li>
                                <li>Right-click the file and select "Get link"</li>
                                <li>Set sharing to "Anyone with the link" → "Viewer"</li>
                                <li>Copy the link and paste it in the form above</li>
                                <li>Our system will automatically convert it to a direct download link</li>
                            </ol>
                        </div>
                        
                        <div class="p-4 bg-gray-50 rounded-xl">
                            <h4 class="font-medium text-gray-800 mb-2">Example Links:</h4>
                            <div class="space-y-2 text-sm">
                                <p class="text-gray-700"><strong>Share link:</strong> <code class="text-xs bg-gray-100 p-1 rounded">https://drive.google.com/file/d/ABC123xyz/view?usp=sharing</code></p>
                                <p class="text-gray-700"><strong>Will become:</strong> <code class="text-xs bg-gray-100 p-1 rounded">https://drive.google.com/uc?export=download&id=ABC123xyz</code></p>
                            </div>
                        </div>
                        
                        <div class="p-4 bg-green-50 rounded-xl">
                            <h4 class="font-medium text-green-800 mb-2">Manual Conversion:</h4>
                            <p class="text-sm text-green-700">
                                Find the FILE_ID in your link (looks like ABC123xyz) and create this direct link:<br>
                                <code class="text-xs bg-green-100 p-1 rounded mt-2 inline-block">https://drive.google.com/uc?export=download&id=FILE_ID</code>
                            </p>
                        </div>
                    </div>
                    
                    <div class="mt-6 text-center">
                        <button onclick="document.getElementById('driveModal').classList.add('hidden')" 
                                class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                            Got it, close this
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Preview app icon
        function previewIcon(event) {
            const input = event.target;
            const preview = document.getElementById('iconPreview');
            const img = document.getElementById('iconPreviewImg');
            
            if(input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    img.src = e.target.result;
                    preview.classList.remove('hidden');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        // Preview screenshots
        function previewScreenshots(event) {
            const input = event.target;
            const preview = document.getElementById('screenshotsPreview');
            const list = document.getElementById('screenshotsList');
            
            list.innerHTML = '';
            
            if(input.files && input.files.length > 0) {
                preview.classList.remove('hidden');
                
                for(let i = 0; i < Math.min(input.files.length, 5); i++) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const div = document.createElement('div');
                        div.className = 'preview-image';
                        div.innerHTML = `
                            <img src="${e.target.result}" class="w-20 h-40 object-cover rounded-lg border">
                            <p class="text-xs text-gray-500 truncate mt-1">${input.files[i].name}</p>
                        `;
                        list.appendChild(div);
                    }
                    reader.readAsDataURL(input.files[i]);
                }
                
                if(input.files.length > 5) {
                    const more = document.createElement('div');
                    more.className = 'flex items-center justify-center w-20 h-40 bg-gray-100 rounded-lg';
                    more.innerHTML = `<span class="text-gray-600">+${input.files.length - 5} more</span>`;
                    list.appendChild(more);
                }
            }
        }
        
        // Convert Drive link on blur
        function convertDriveLink(input) {
            let link = input.value.trim();
            if(!link) return;
            
            // Simple client-side conversion
            let fileId = '';
            
            // Pattern 1: /d/FILE_ID/
            let match = link.match(/\/d\/([a-zA-Z0-9_-]+)/);
            if(match) fileId = match[1];
            
            // Pattern 2: id=FILE_ID
            if(!fileId) {
                match = link.match(/id=([a-zA-Z0-9_-]+)/);
                if(match) fileId = match[1];
            }
            
            // Pattern 3: /file/d/FILE_ID/
            if(!fileId) {
                match = link.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
                if(match) fileId = match[1];
            }
            
            if(fileId && !link.includes('uc?export=download')) {
                input.value = `https://drive.google.com/uc?export=download&id=${fileId}`;
                showMessage('Link converted to direct download format', 'success');
            }
        }
        
        // Show Drive help
        function showDriveHelp() {
            document.getElementById('driveModal').classList.remove('hidden');
        }
        
        // Show message
        function showMessage(text, type) {
            const div = document.createElement('div');
            div.className = `fixed top-4 right-4 p-4 rounded-xl shadow-lg z-50 ${type === 'success' ? 'bg-green-100 text-green-800 border border-green-200' : 'bg-yellow-100 text-yellow-800 border border-yellow-200'}`;
            div.innerHTML = `
                <div class="flex items-center space-x-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span>${text}</span>
                </div>
            `;
            document.body.appendChild(div);
            
            setTimeout(() => {
                div.remove();
            }, 3000);
        }
        
        // Form submission
        const form = document.getElementById('uploadForm');
        form.addEventListener('submit', function() {
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = 'Submitting...';
            submitBtn.classList.add('opacity-75');
        });
    </script>
</body>
</html>
<?php 
$cats_stmt->close();
$conn->close();
?>