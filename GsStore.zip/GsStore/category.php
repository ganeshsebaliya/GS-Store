<?php
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories - Gs Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .category-active { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header (same as index.php) -->
    <header class="sticky top-0 z-50 bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <a href="index.php" class="text-white font-bold text-xl">Gs Store | Build With Satya</a>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="profile.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                    </a>
                    <a href="login.php" class="text-white hover:bg-white/20 p-2 rounded-full transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </header>
    
    <main class="container mx-auto px-4 py-6 pb-24">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Browse Categories</h1>
        
        <!-- Categories Filter -->
        <div class="mb-8">
            <div class="flex overflow-x-auto pb-4 space-x-2">
                <a href="category.php" 
                   class="flex-shrink-0 px-4 py-2 rounded-full bg-white shadow-md hover:shadow-lg transition <?php echo !isset($_GET['cat_id']) ? 'category-active' : 'text-gray-700'; ?>">
                    All Apps
                </a>
                <?php
                $cats_sql = "SELECT * FROM categories ORDER BY name";
                $cats_stmt = $conn->prepare($cats_sql);
                $cats_stmt->execute();
                $cats_result = $cats_stmt->get_result();
                
                $selected_cat = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
                
                while($cat = $cats_result->fetch_assoc()):
                ?>
                <a href="category.php?cat_id=<?php echo $cat['id']; ?>" 
                   class="flex-shrink-0 px-4 py-2 rounded-full bg-white shadow-md hover:shadow-lg transition <?php echo $selected_cat == $cat['id'] ? 'category-active' : 'text-gray-700'; ?>">
                    <?php echo htmlspecialchars($cat['name']); ?>
                </a>
                <?php endwhile; 
                $cats_stmt->close();
                ?>
            </div>
        </div>
        
        <!-- Search Filter -->
        <div class="mb-6">
            <div class="relative">
                <input type="text" id="appSearch" 
                       class="w-full px-4 py-3 pl-12 rounded-xl bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                       placeholder="Search apps in this category...">
                <div class="absolute left-4 top-3.5">
                    <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                </div>
            </div>
        </div>
        
        <!-- Apps Grid -->
        <div id="appsContainer">
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                <?php
                $selected_cat = isset($_GET['cat_id']) ? intval($_GET['cat_id']) : 0;
                
                $apps_sql = "SELECT a.id, a.title, a.icon, a.downloads, c.name as category_name 
                            FROM apps a 
                            LEFT JOIN categories c ON a.category_id = c.id 
                            WHERE a.status = 'approved'";
                
                if($selected_cat > 0) {
                    $apps_sql .= " AND a.category_id = ?";
                }
                
                $apps_sql .= " ORDER BY a.created_at DESC";
                
                $apps_stmt = $conn->prepare($apps_sql);
                if($selected_cat > 0) {
                    $apps_stmt->bind_param("i", $selected_cat);
                }
                $apps_stmt->execute();
                $apps_result = $apps_stmt->get_result();
                
                while($app = $apps_result->fetch_assoc()):
                ?>
                <a href="app.php?id=<?php echo $app['id']; ?>" 
                   class="app-card bg-white rounded-xl shadow-md hover:shadow-xl hover:scale-105 transition-transform duration-200">
                    <div class="p-4">
                        <img src="assets/uploads/icons/<?php echo htmlspecialchars($app['icon']); ?>" 
                             alt="<?php echo htmlspecialchars($app['title']); ?>"
                             class="w-20 h-20 mx-auto rounded-2xl object-cover">
                        <div class="mt-4">
                            <h3 class="font-semibold text-gray-800 text-center truncate"><?php echo htmlspecialchars($app['title']); ?></h3>
                            <?php if($app['category_name']): ?>
                            <p class="text-xs text-gray-500 text-center mt-1"><?php echo htmlspecialchars($app['category_name']); ?></p>
                            <?php endif; ?>
                            <p class="text-xs text-blue-600 text-center mt-2"><?php echo number_format($app['downloads']); ?> downloads</p>
                        </div>
                    </div>
                </a>
                <?php endwhile; 
                $apps_stmt->close();
                
                if($apps_result->num_rows === 0):
                ?>
                <div class="col-span-full text-center py-12">
                    <div class="text-gray-400 mb-4">
                        <svg class="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-600 mb-2">No apps found</h3>
                    <p class="text-gray-500">Try selecting a different category</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <!-- Footer Navigation (same as index.php) -->
    <footer class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 py-3 z-40">
        <div class="container mx-auto px-4">
            <div class="flex justify-around">
                <a href="index.php" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
                    <div class="p-2 rounded-full hover:bg-blue-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                    </div>
                    <span class="text-xs mt-1">Home</span>
                </a>
                
                <a href="category.php" class="flex flex-col items-center text-blue-600">
                    <div class="p-2 rounded-full bg-blue-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                        </svg>
                    </div>
                    <span class="text-xs mt-1">Categories</span>
                </a>
                
                <a href="profile.php" class="flex flex-col items-center text-gray-600 hover:text-blue-600">
                    <div class="p-2 rounded-full hover:bg-blue-50">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                    </div>
                    <span class="text-xs mt-1">Profile</span>
                </a>
            </div>
        </div>
    </footer>
    
    <script>
        // Client-side search filter
        const appSearch = document.getElementById('appSearch');
        const appCards = document.querySelectorAll('.app-card');
        
        appSearch.addEventListener('input', function() {
            const query = this.value.toLowerCase().trim();
            
            appCards.forEach(card => {
                const title = card.querySelector('h3').textContent.toLowerCase();
                if(title.includes(query)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
        
        // Footer button animation
        document.querySelectorAll('footer a').forEach(link => {
            link.addEventListener('click', function(e) {
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 200);
            });
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>